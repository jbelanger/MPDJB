<?php

/* * * * * * * * * * * * * * * * * * * * * * * * * *\
 * Display Song information.
 * - Cover art if available. 
 * - Metadata info from MPD 
 * - Song remaining time
 * This page is accessed via the Now Playing label
 * in the main interface
 * * * * * * * * * * * * * * * * * * * * * * * * * */

require_once("lib/utils.php");
require_once("lib/config.php");
require_once("lib/template.php");
require_once("lib/library.php");
require_once("lib/mpd.php");

global $config, $fp, $current_song, $lang;

	$starttime = microtime_float();
		
	$songid = (isset($_GET['song']))? $_GET['songid']:0;
	
	// Retrieve required configuration
	init_session();
	read_config();
	$page_info = get_page_info();
	require_once("lib/lang/".$config['language']); 
	
	// MPD 
	$fp = get_mpd_handle();
	parse_actions();
	
	$current_song = mpd_command("currentsong");	
	$status = mpd_command("status");
	$current_song = array_merge($status, $current_song);

	if($fp)
	  fclose($fp);

	// Page setup
	$page = new Page($config['title_template']);
	$side_menu = "<span id=\"time\" class=\"clock\">.</span>";
	$miniplayer = showMiniPlayer($status);
	$time_parts = explode(":", $status['time']);

	// Song remaining time
	if($status["state"] == "play"){
		$remaining = ($time_parts[1] - $time_parts[0]);
	}
	else{
		// virtually forever
		$remaining = 1000000;
	}
		
	$page->replace_tags(array(
	  "title" 		=> "MPDJB",
	  "charset" 	=> $config['charset'],
	  "style" 		=> "style.dat", 
	  "background" => $config['background'],
	  "menu" 		=> "",
	  "miniplayer" => $miniplayer,
	  "libraryinfo" => "<a href=\"javascript:history.go(-1);\"><img border=\"0\" src=\"".$config['link']."images/prevpage2.png\" onfocussrc=\"".$config['link']."images/prevpagemo.png\" height=\"".(40 *$config['relative_size'])."\" width=\"".(40 *$config['relative_size'])."\"></a>",//$page_data['header'], 
	  "side_menu"	=> $side_menu,
	  "refresh_time" => $remaining,
	  "files" 		=>  get_song_info(),
	));

	$time_parts = explode(":", $current_song['time']);
	if($current_song['state'] == "play"){
		$page->page = str_replace("starttime=0", "starttime=$time_parts[0]", $page->page);
		$page->page = str_replace("endtime=0", "endtime=$time_parts[1]", $page->page);
	}
	elseif($status["state"] == "pause")
	{
		$page->page = str_replace("starttime=0", "starttime=$time_parts[0]", $page->page);
		$page->page = str_replace("endtime=0", "endtime=$time_parts[0]", $page->page);
	}

		  
	$pagetime = round((microtime_float() - $starttime), 3);        
	$page->page = str_replace("{ms}", $lang['generated'].$pagetime." ".$lang['seconds'], $page->page);
	
	$page->output();


function get_song_info()
{
	global $current_song, $config, $lang;
	
	$tags = array(
		"AlbumArtist" 	=> $lang['albumartist'],
		"Genre" 		=> $lang['genre'],
		"Time" 			=> $lang['tracktime'],
		"Date"			=> $lang['year'],
		"Composer" 		=> $lang['composer'],
		"Track" 		=> $lang['track'],
	);
	
	$html .= "<table class=\"textstyle1\">";
	$html .= 	"<tr>";
	$html .= 		"<td width=\"".(300 *$config['relative_size'])."\"><img src=\"".get_album_image($current_song['file'])."\" width=\"".(275 *$config['relative_size'])."\" height=\"".(275 *$config['relative_size'])."\"></td>";
	$html .= 		"<td valign=\"top\">";
	$html .= 			"<b><font class=\"title\">".$current_song['Title']."</font></B><br>";
	$html .= 			"<font class=\"title2\">".$current_song['Artist']."</font><br>";
	$html .= 			"<font class=\"title2\">".$current_song['Album']."</font><br>";
	$html .= 		"</td>";
	$html .= 	"</tr>";
	$html .= 	"<tr><td colspan=\"2\" height=\"10\"></td></tr>";
	$html .= 	"<tr>";
	$html .= 		"<td colspan=\"2\">";
	$html .= 			"<table class=\"textstyle1\">";
	$html .= 				"<tr>";
	
	foreach($tags as $t => $value)
	{
		$tag_data = $current_song[$t];
		if(!empty($tag_data)){
			if($count == 2)
			{
				$html .= 	"</tr>";
				$count = 0;
			}
			if($t == "Time")
				$tag_data = time_to_readable($tag_data);	
			$html .=			"<td width=\"".(400 *$config['relative_size'])."\"><font class=\"listitem\">".$value.": ".$tag_data."</font></td>";
			$count++;
		}			
	}
	
	$html .= ($count == 2)? "</tr>" : "";

	
	if(!empty($current_song['audio'])){
		$parts = explode(":",$current_song['audio']);
		$html .= 				"<td width=\"".(400 *$config['relative_size'])."\"><font class=\"listitem\">".$lang['audio'].": ".$parts[0]." KHz, ".$parts[1]." Bit, ".$parts[2]." ".$lang['channels']."</font></td>";
		$count++;
		$html .= ($count == 2)? "</tr>" : "";
		$html .= 				"<td width=\"".(400 *$config['relative_size'])."\"><font class=\"listitem\">".$lang['bitrate'].": ".$current_song['bitrate']." kbps</font></td>";
	}
	else
	{
		$html .= 				"<td></td>";
	}
	$html .= 				"</tr></table>";
	$html .= 		"</td><td></td></tr>";
	$html .= "</table>";
	
	return $html;		
}

function get_album_image2()
{
	global $current_song, $config;
	
	$album_path =  $config['mpd']['mpd_music_path']."/".pathinfo($current_song['file'], PATHINFO_DIRNAME);
	
	if(is_file($album_path."/".$config['album_art']))
		$fileicon = "file://".$album_path."/".$config['album_art'];
	else
		$fileicon = $config['link']."images/music_folder.png";
	
	return $fileicon;
}

?>
