<?php
require_once("lib/config.php");
require_once("lib/utils.php");
require_once("lib/ini.php");
require_once("lib/mpd.php");

global $config, $lang, $page_info;

init_session();
read_config();
$page_info = get_page_info();

// Checks if something needs to be updated
if(isset($_GET['rows']))
{
	$arr = array();
	// Update config
	read_ini_file(getcwd()."/mpdjb.conf", $arr);
	
	$arr['main']['listview_rows'] = $_GET['rows'];
	$config['listview_rows'] = $_GET['rows'];
	$arr['main']['listview_columns'] = $_GET['columns'];
	$config['listview_columns'] = $_GET['columns'];
	$arr['main']['nb_albums'] = $_GET['albumitems'];
	$config['nb_albums'] = $_GET['albumitems'];
	$arr['main']['albummode'] = $_GET['albummode'];
	$config['albummode'] = $_GET['albummode'];


	
	$arr['main']['language'] = $_GET['lang'];
	$config['language'] = $_GET['lang'];
	
	
	$arr['main']['background'] = $_GET['background'];
	$config['background'] = "images/background/".$_GET['background'];
	
	write_ini_file("mpdjb.conf", $arr);
	
	if (isset($_COOKIE[session_name()])) {
		@setcookie(session_name(), '', time()-42000, '/');
	}
	
	@session_destroy();
	
	
	$host  = $_SERVER['HTTP_HOST'];
	$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
	$extra = "setup.php";
	echo "<script>location.replace(\"http://".$host.$uri."/".$extra."\");</script>";
   
}
elseif(isset($_GET['action']))
{
	// Update database
	parse_actions();
	destroy_session();
}

require_once("lib/lang/".$config['language']);
	
$menu_option = (isset($_GET['menuoption']))? $_GET['menuoption'] : "appearance";


  $relative_size = ($config['screensetup'] == "hd")? 1 : 0.55;
?>
<html>                         
   <head>   	                                      
      <title>                                     
      </title>   	                                      
      <style type="type/css">
	  
	  
	  
	  
 	  
		.form_elements{ color:white;}	  
		.menu {font-size:<?=(20*$relative_size)?>px;color:#B1D3F6;font-weight:bold; }	
		.menu_highlighted {font-size:<?=(20*$relative_size)?>px;color:#FFFFFF;font-weight:bold;}
		.menuoption { background-color:black-alpha3; height:<?=(45*$relative_size)?>px; width:<?=(225*$relative_size)?>px;}
		.menuoption_sel { background-color:teal-alpha; height:<?=(45*$relative_size)?>px; width:<?=(225*$relative_size)?>px;}
		.menuoption_sel a{ color:#B1D3F6;font-weight:bold; font-size:<?=(22*$relative_size)?>px; text-decoration:none; }
		.menuoption a{ color:#B1D3F6;font-weight:bold; font-size:<?=(22*$relative_size)?>px; text-decoration:none; }	
		.textstyle1 {color:#B1D3F6;}
		.description {color:#B1D3F6;font-size:<?=(18*$relative_size)?>px; }
		.title{font-size:<?=(35*$relative_size)?>px;color:#B1D3F6;}
		.title2{font-size:<?=(25*$relative_size)?>px;color:#B1D3F6;}
      </style>
      <meta http-equiv="content-type" content="text/html; charset=<?=$config['charset']?>">   	                                      
      <meta http-equiv="expires" content="0">                                            
      <meta http-equiv="pragma" content="no-cache">                                            
      <meta http-equiv="cache-control" content="no-cache, must-revalidate">                                                           
   </head>                        
   <body onloadset="<?=(isset($_GET['menuoption'])? $_GET['menuoption']: "appearance") ?>" background="<?=$config['background']?>" bgcolor="#398EC4" color="#ffffff" marginwidth="0" marginheight="0" focustext="FFFFFF" >                                                
		<a href="#" ONFOCUSSET="appearance"></a>
		<table cellpadding=0 cellspacing=0 border=0 width="<?=(1100 * $relative_size)?>">                                                                          
    		<tr>  
    			<td colspan="2" valign="top">	
            		<font class="title">MPDJB - <I><?=$lang['setup']?></I></font><br />
            	</td>
            </tr>
            <tr>
            	<td height="<?=(50 * $relative_size)?>"></td>                                                   
            </tr>                                                              
            <tr>                                                                                         
            	<td rowspan="18" width="<?=(250 * $relative_size)?>" valign="top">                                                                                      
                <table valign="top">                                                                                                  
                     <tr>                                                                                  
                        <td class="menuoption">&nbsp;&nbsp;                                                                          
                           <a href="javascript:history.go(-1);"><?=$lang['back']?></a></td>                                                                                       
                     </tr>                                                                                                       
                     <tr>                                                                                  
                        <td class="<? if($menu_option == "appearance") echo "menuoption_sel"; else echo "menuoption"; ?>">&nbsp;&nbsp;                                                                          
                           <a name="appearance" href="javascript:location.replace('<?=$config['link']."setup.php?menuoption=appearance"?>');"><?=$lang['appearance']?></a></td>                                                                                       
                     </tr>                                                                                                       
                     <tr>                                                                                  
                        <td class="<? if($menu_option == "mpd") echo "menuoption_sel"; else echo "menuoption"; ?>">&nbsp;&nbsp;                                                                          
                           <a name="mpd" href="javascript:location.replace('<?=$config['link']."setup.php?menuoption=mpd"?>');"><?=$lang['mpd_menu_option']?></a></td>                                                                                       
                     </tr>                                                                                                  
                     <tr>                                                                                  
                        <td class="menuoption">&nbsp;&nbsp;    
                                                                                              
                        <a href="file:///opt/sybhttpd/default/preferences.htm"><?=$lang['mainsetup']?></a></td>                                                                                       
                     </tr>
                                          <tr>                                                                                  
                        <td class="menuoption">&nbsp;&nbsp;    
                                                                                              
                       <a name="reload" href="javascript:location.replace('<?=$config['link']."setup.php?menuoption=reload"?>');"><?=$lang['reload']?></a></td>                                                                                       
                     </tr>                                                                                                                                                                                        
                  </table>          </td>                                                                                             
                                       
<?
/* -- APPEARANCE -- */  
if($menu_option == "appearance")
{
?>                                                                
	<td bgcolor="black-alpha" valign="top" height="<?=(425 * $relative_size)?>">
		<form action="<?=$config['link']."setup.php" ?>" method="get">
			<table cellpadding="5" cellspacing="5">
				<tr>
					<!-- ROWS -->
					<td width="<?=(650 * $relative_size)?>">
						<U><font class="menu" color="white"><?=$lang['rows']?></font></U>
						<BR />
                  		<font class="description"><?=$lang['rowsdesc']?></font>
                  	</TD>                                                                                          
               		<td width="<?=(200 * $relative_size)?>" valign="top">                                                                                                          
						<select class="menu" name="rows">            
<?
	for($i=10;$i<=14;$i++)
	{
?>                                                                                                                       
							<option value="<?=$i?>"               
<?
             if($i == $config['listview_rows'])
                echo "SELECTED";       
?>
							>                                                                                                       
							<?=$i?>                                                                                                       
							</option>                
<?
	}
?>                                                                                                                            
						</select>
					</td>                                                                     
				</tr>                                                                                                               
            	<tr>
            		<!-- COLUMNS -->                                                                                 
            		<td width="<?=(650 * $relative_size)?>">
            			<U><font class="menu" color="white"><?=$lang['columns']?></font></U>
            			<BR />
            			<font class="description"><?=$lang['columnsdesc']?></font>
            		</TD>                                                                                      
               		<td width="<?=(200 * $relative_size)?>" valign="top">                                                                         
                  		<select name="columns">            
<?
              for($i=1;$i<=4;$i++)
              {
                                                                                                                                       ?>                                                                                                                       
                     <option value="<?=$i?>"               
<?
             if($i == $config['listview_columns'])
                echo "SELECTED";       
                                                                                                                                       ?>              >                                                                                                       
                     <?=$i?>                                                                                                       
                     </option>                
<?
              }
                                                                                                                                   ?>                                                                                                                            
                  </select>                                </td>                                                                     
            </tr>                                                                                  
            <!-- ALBUMVIEW MODE-->                                           
            <tr>                                                                                
               <td width="<?=(600 * $relative_size)?>"><u>                                                                                                  
                     <font class="menu" color="white"><?=$lang['albummode']?>                                                                                                   
                     </font></u><BR />                                                              
                  <font class="description"><?=$lang['albummodedesc']?>                                                                
                  </font></TD>                                                                                      
               <td width="<?=(200 * $relative_size)?>" valign="top">                                                                                                      
                  <select name="albummode">
                  <?
                  $options = array("1" => $lang['tile'], "2" => $lang['icon']);
                  
                  foreach($options as $l => $value)
                  {
                  ?>                                                                                                                      
                     <option value="<?=$l?>" <?
                     if($l == $config['albummode'])
                        echo "SELECTED";  
                     ?>><?=$value?>                                                                                                                 
                     </option>                          
                     <?
                  }   
                     ?>                                                                                            
                                                                                                         
                  </select>    </td>                                                                     
            </tr> 
                        <!-- ALBUMVIEW NUMBER OF ITEMS-->                                           
            <tr>                                                                                
               <td width="<?=(600 * $relative_size)?>"><u>                                                                                                  
                     <font class="menu" color="white"><?=$lang['albumview']?>                                                                                                   
                     </font></u><BR />                                                              
                  <font class="description"><?=$lang['albumviewdesc']?>                                                                
                  </font></TD>                                                                                      
               <td width="<?=(200 * $relative_size)?>" valign="top">                                                                                                      
                  <select name="albumitems">
                  <?
                  $options = array("14" => "14", "30" => "30");
                  
                  foreach($options as $l => $value)
                  {
                  ?>                                                                                                                      
                     <option value="<?=$l?>" <?
                     if($l == $config['nb_albums'])
                        echo "SELECTED";  
                     ?>><?=$value?>                                                                                                                 
                     </option>                          
                     <?
                  }   
                     ?>                                                                                            
                                                                                                         
                  </select>    </td>                                                                     
            </tr>    
            <!-- LANGUAGES -->                                           
            <tr>                                                                                
               <td width="<?=(600 * $relative_size)?>"><u>                                                                                                  
                     <font class="menu" color="white"><?=$lang['language']?>                                                                                                   
                     </font></u><BR />                                                              
                  <font class="description"><?=$lang['langdesc']?>                                                                
                  </font></TD>                                                                                      
               <td width="<?=(200 * $relative_size)?>" valign="top">                                                                                                      
                  <select name="lang">
                  <?
                  $languages = array("en_uk" => "English", "fr_ca" => "Francais", "ge_de" => "Deutsch", "nl_nl" => "Nederlands");
                  
                  foreach($languages as $l => $value)
                  {
                  ?>                                                                                                                      
                     <option value="<?=$l?>" <?
                     if($l == $config['language'])
                        echo "SELECTED";  
                     ?>><?=$value?>                                                                                                                 
                     </option>                          
                     <?
                  }   
                     ?>                                                                                            
                                                                                                         
                  </select>    </td>                                                                     
            </tr>                                                                                            
            <tr>                                                                                   
               <td width="<?=(650 * $relative_size)?>">  <u>                                                                                                  
                     <font class="menu" color="white"><?=$lang['background']?>                                                                                                  
                     </font></u><br />                                                              
                  <font class="description"><?=$lang['backgrounddesc']?>                                                                
                  </font></TD>                                                                                      
               <td width="<?=(200 * $relative_size)?>" valign="top">  
               <select name="background"> 
               <?
               
               $d = dir(getcwd()."/images/background");
               
               while (false !== ($entry = $d->read())) {
               
               if($entry[0] != '.' && pathinfo($entry,PATHINFO_EXTENSION) == "jpg"){
               
               ?>
               <option value="<?=$entry?>" <?
               
               if("images/background/".$entry == $config['background'])   
                  echo "SELECTED";
               ?>
               >
               <?=$entry?> 
                                    </option>   
               <?}
                  
               }
                 ?>                                                                                                  
               </td>                                                                     
            </tr>                                                                                                            
            <tr>                                                                          
            		<td><br/><br/><br/></td>                                                          
            </tr>                                                                     
            <tr><td></td>                                                                          
               <td  align="left">                                                                                        
                  <input type="submit" value="<?=$lang['apply']?>"   /></td>  </tr></table>
                        </form>  
                  </td>                         
<?
           }
           /* -- MPD -- */
           elseif($menu_option == "mpd")
           {
                                                                            ?>                                                                  
               <td valign="top" align="left" height="<?=(425 * $relative_size)?>" width="<?=(850 * $relative_size)?>" class="menu" bgcolor="black-alpha">
               &nbsp;<b><u><font color="white"><?=$lang['mpdsettings']?></font></u></b>
                  <table cellpadding="5" cellspacing="2" class="menu">                                                                               
                     <tr>                                                                 
                        <td align="left" width="<?=(550 * $relative_size)?>"><?=$lang['host']?>:<td width="<?=(100 * $relative_size)?>"><?= (!empty($config['mpd']['host']))? $config['mpd']['host'] : "N/A"; ?></td>                                                        
                     </tr>   
                     <tr>                                                                 
                        <td width="<?=(550 * $relative_size)?>">Port: </td><td>                                                                         
                           <?= (!empty($config['mpd']['port']))? $config['mpd']['port'] : "N/A"; ?></td>                                                         
                     </tr>                                                                             
                     <tr>                                                                 
                        <td width="<?=(550 * $relative_size)?>"><?=$lang['musicpath']?>: </td><td>                                                                         
                           <?= (!empty($config['mpd']['mpd_music_path']))? $config['mpd']['mpd_music_path'] : "N/A"; ?></td>                                                         
                     </tr>                                                                               
                     <tr>                                                                 
                        <td width="<?=(550 * $relative_size)?>"><?=$lang['playlistpath']?>: </td><td>                                                                         
                           <?= (!empty($config['mpd']['mpd_playlist_path']))? $config['mpd']['mpd_playlist_path'] : "N/A"; ?></td>                                                         
                     </tr>                                                                       
                  </table>
                  <hr>
                  <table cellpadding="5" cellspacing="2" ><tr><td width="<?=(550 * $relative_size)?>"><font class="menu"><?=$lang['mpdupdate']?></font><br />
                  </td><td valign="bottom"><form method="get" action="<?=$config['link']."setup.php?menuoption=mpd&action=update"?>">
                  <?if(isset($_GET['action']))
                  {
                  ?>
	                  <input class="form_elements" disabled type="button" value="Updating..."/>
                  <?
                  }
                  else
                  {
                  ?>
                  	<input class="form_elements" type="button" value="GO"/>
                  <?
                  }
                  ?>
                  </form></td></tr></table>
                  </td>                                                                
<?
           }
         // Destroy previous session
         elseif($menu_option == "reload")
         {
			destroy_session();

         
         ?><td valign="top" class="menu" height="<?=(425 * $relative_size)?>" bgcolor="black-alpha">
            &nbsp;<?=$lang['reloaded']?>
            </td>
         <?
         
         }
		?>                                                         
            </tr>                                                         
         </table>                                                   
                          
   </body>
</html>
<?
?>