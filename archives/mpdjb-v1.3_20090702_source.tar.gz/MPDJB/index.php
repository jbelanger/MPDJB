<?php
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *	MPDJB v1.1
 *	24th June 2009
 *	Main page that is used to call everything else based on
 *  selection.   
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

// Globals
global $filefirst, $filelast, $config, $lang, $page_info, $fp;

require_once("lib/utils.php");
require_once("lib/config.php");
require_once("lib/template.php");
require_once("lib/mpd.php");
require_once("lib/playlist.php");
require_once("lib/dataview.php");
require_once("lib/library.php");

// ---------------------
// Begin page generation
// ---------------------
$starttime = microtime_float();

//----------------------------------------------
// Session will be used to cache large folders, 
// access time improved on subsequent hits.
// It will also stored the configuration so it doesn't
// load each time.
//----------------------------------------------
init_session();
read_config();

// Parse page specific values, ie querystring..  
$page_info = get_page_info();

// Once we have the config, determine user language 
// and load localization file
require_once("lib/lang/".$config['language']);

$page = new Page($config['template']);	

$fp = get_mpd_handle();		
$result = parse_actions();

// Item view based on selected category 
$page_data = get_page_data();
$files = $page_data['files'];
$view = $page_data['view'];	

// Current MPD status 
$status = getStatusInfo();
if(isset($status["error"])) {
	print "Error: " . $status["error"] . "<br>\n";
}
$miniplayer = showMiniPlayer($status);
$np = now_playing($status);

// Song remaining time
if($status["state"] == "play"){
	$time_p = explode(":",$status['time']);
	$remaining = $time_p[1] - $time_p[0];
	}
else{
	// virtually forever
	$remaining = 1000000;
}

$js = save_playlist_option();


$page->replace_tags(array(
  "title" 			=> "MPDJB",
  "charset" 		=> $config['charset'],
  "style" 			=> "style.dat", 
  "background" 		=> $config['background'],
  "category"		=> category_menu(),
  "listing_menu"	=> listing_menu(),
  "log"				=> ($result)? "<font class=\"letters\">Last command: ".$result."</font>" : "",
  "menu" 			=> show_items_count($files)."<br />".(pageBrowser($view, $files)),
  "refresh_time" 	=> $remaining,
  "javascript"		=> $js,
  "miniplayer" 		=> $miniplayer,
  "nowplaying" 		=> $np, 
  "libraryinfo" 	=> $page_data['header'], 
  "files" 			=> $page_data['data'],
));

$page->replace_tags(array(
  "filefirst" => "$filefirst",
  "filelast" => "$filelast",
));


$pagetime = round((microtime_float() - $starttime), 3);        
$page->page = str_replace("{ms}", $lang['generated'].$pagetime." ".$lang['seconds'], $page->page);

$page->output();

if($fp)
  fclose($fp);
?>
