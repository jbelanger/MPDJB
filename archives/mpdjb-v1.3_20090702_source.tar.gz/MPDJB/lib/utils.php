<?php

/* Ex: MAX_PAGES_TO_SHOW=9 => "<< < 1 2 3 4 5 6 7 8 9 > >>" */
define("MAX_PAGES_TO_SHOW",9);  //Must be Odd number

// Used to calculate page generation time
function microtime_float()
{
    list($usec, $sec) = explode(" ", microtime());
    return ((float)$usec + (float)$sec);
}

function init_session()
{
	session_name("mpdjb");
	
	session_save_path("tmp");
		
	if(session_start() == false)
		exit();
}

function destroy_session()
{
	if (isset($_COOKIE[session_name()])) {
		@setcookie(session_name(), '', time()-42000, '/');
	}

	@session_destroy();

}

function time_to_readable($int_time)
{
	global $lang;

	if($int_time > (24*3600)){
		$date = date("z:H:i:s",$int_time);
		$parts = explode(":",$date);
		if($parts[0] == 1)
			$ret = "1 day, ".$parts[1].":".$parts[2].":".$parts[3];
		else
			$ret = $parts[0]." ".$lang['days'].", ".$parts[1].":".$parts[2].":".$parts[3];
	}
	elseif($int_time > 3600){
		$ret = date("h:i:s",$int_time);
	}
	else
		$ret = date("i:s",$int_time);
		  
	return $ret;
}


function pageBrowser($view, $files)
{

  $begin = floor(MAX_PAGES_TO_SHOW / 2);
  $ends = ceil(MAX_PAGES_TO_SHOW / 2);
  
  global $config, $page_info;
  
	if($view == $config['constants']['ALBUMVIEW'])
		$maxFiles = $config['nb_albums'];
	else
		$maxFiles = $config['maxFiles'];
  
  $link = $config['link'];
   
  $num = count($files);

  if($num > $maxFiles)
  	$pages = intval($num/$maxFiles);
  else
  	return;

  $current_page = $_GET['pg'];
 
  // PG=0
  if($current_page == null || $current_page == 0)
    $current_page = 0;
  elseif($current_page > 0)
  {
    if($current_page > $begin)
      $strHTML = "<a href=".$link."index.php?".$page_info->path."&pg=0 onkeydownset='artists'> << </a> "; 
    $prev_page = ($current_page > 0) ? $current_page -1 : 0;
    $strHTML .= "<a href=".$link."index.php?".$page_info->path."&pg=".$prev_page." onkeydownset='artists'> < </a> ";  
  }
  
  for($i=($current_page-$begin);$i<($current_page+$ends);$i++)
  {
    if($i < 0)
      continue;
    elseif($i == ($pages+1))
      break;
    
    $href = $link."index.php?".$page_info->path."&pg=".$i;
    $innerA = ($i == ($pages-1)) ? $i : $i." - ";
    if($current_page == $i)
      $strHTML .= "<a href=".$href." onkeydownset='artists'>&nbsp;<FONT color=\"white\">".($i+1)."</FONT>&nbsp;</a>";
    else
      $strHTML .= "<a href=".$href." onkeydownset='artists'>&nbsp;".($i+1)."&nbsp;</a>";
  }

  if(($current_page)< $pages)
    $strHTML .= "<a href=".$link."index.php?".$page_info->path."&pg=".($current_page+1)." onkeydownset='artists'> > </a> ";
      if(($current_page +$ends) < ($pages+1))


        $strHTML .= "<a href=".$link."index.php?".$page_info->path."&pg=".$pages." onkeydownset='artists'> >> </a> ";
  
  return $strHTML;
}

function show_items_count($files)
{
	global $lang, $config, $page_info;
	
	if(isset($_GET['album']) || $page_info->category == $config['constants']['ALBUMS'])
		$maxFiles = $config['nb_albums'];
	else
		$maxFiles = $config['maxFiles'];

	
  	$num = count($files);   
  	$page = ($_GET['pg'] >= 0) ? $_GET['pg'] : intval($num/$maxFiles);
  	$page -= ($_GET['goto'] == "Prev") ? 1 : 0;
  	$page += ($_GET['goto'] == "Next") ? 1 : 0;
  	$page = (($maxFiles*$page)+1 > $num) ? 0 : $page;
                                                  
  	$from = ($maxFiles * $page) + 1;
  	$to = $from + $maxFiles - 1;
                                                  
  	if ($to > $num) { $to = $num; }
			      
    return "<font class=\"letters\">".$from." ".$lang['pageto']." ".$to." ".$lang['pageof']." ".$num." ".$lang['pageitems']."</font>";

}

function show_browse_letters($array)
{
  global $config;
  
  $arr = get_start_letters($array);
  $maxFiles = 36;
  foreach($arr as $letter => $value)
  {
    $html .= "<a href=\"".$config['link']."index.php?pg=".floor($value/$maxFiles)."\">".$letter."</a>&nbsp;";
  }
  return $html;
}

function get_start_letters($array)
{
  $len = count($array);
  
  for($i=0;$i<$len;$i++)
  {
    $name = $array[$i];
    $char = strtoupper($name{0});

    if(!$fl[$char])
      $fl[$char] = $i;
  }
  return $fl; 
}

function parseInt($string) {

	if(preg_match('/(\d+)/', $string, $array)) {
		return $array[1];
	} else {
		return 0;
	}
}

function get_album_image($file)
{
	global $config;
	
	$album_path =  $config['mpd']['mpd_music_path']."/".pathinfo($file, PATHINFO_DIRNAME);
	
	if(is_file($album_path."/folder.jpg"))
		$fileicon = "http://".$_SERVER['HTTP_HOST']."/stream/file=".$album_path."/folder.jpg";
	else
		$fileicon = $config['link']."images/music_folder.png";
	
	return $fileicon;
}


?>
