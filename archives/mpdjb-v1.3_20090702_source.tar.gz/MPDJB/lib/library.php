<?php

/************************************************
 * Main function used to retrieve the data that 
 * will be displayed in the file area			
 ************************************************/ 
function get_page_data()
{
	global $page_info, $config;
	
	$category = $page_info->category;	
	$view = "";
	
	// Folder selected, print songs or albums within that dir
	if(!empty($page_info->listitem))
	{  
		$listitem = $page_info->listitem;
		if($category == $config['constants']['ARTISTS'])
		{	
		
			// When browsing by artist, we can choose 
			// to display either by albums or by songs
			if(!empty($page_info->album))
			{
				$album = urldecode($page_info->album);
				$files = get_list("title", "artist \"".$listitem."\" album \"".$album."\"");
				$data = listview($files, $config['constants']['SONGVIEW']);
				$header = album_info($files);	
			}
			else{						
				if(isset($_GET['toggle']))
					$_SESSION['artistview'] = $_GET['toggle'];
				
				if($_SESSION['artistview'] == "songs"){
					$files = get_list("title", "artist \"".$listitem."\"");
					$data = listview($files, $config['constants']['SONGVIEW']);
				}
				else{
					$files = get_list("album", "artist \"".$listitem."\"");
					$data = albumview($files);
					$view = $config['constants']['ALBUMVIEW'];
				}
				$header = artist_album_infos($files);	
			}
		}
		elseif($category == $config['constants']['FOLDERS'])
		{
			$files = get_list($category,"\"".$listitem."\"", true);
			$data = listview($files, $config['constants']['LISTVIEW']);            
			$header = folder_info($listitem, $files);
		}
		else
		{
			// Album, genre of playlist item selected, display songs
			$files = get_list("title", $category." \"".$listitem."\"");
			$data = listview($files, $config['constants']['SONGVIEW']);            
			$header = listitem_info($listitem, $files);
		} 
	}
	elseif($category == $config['constants']['NOWPLAYING'])
	{
		$files = get_playlist_songs();
		$data = listview($files, $config['constants']['SONGVIEW']);  
		$header = playlist_infos($files);
	}
	else
	{
		if(isset($_SESSION[$category])){
			$files = $_SESSION[$category];
		}
		else{
			if($category == $config['constants']['PLAYLISTS'])
				$files = get_playlists();				
			else
				$files = get_list($category,"", true);
			$_SESSION[$category] = $files;
		}

		$header = library_info();
		
		if($category == "album"){
			$data = albumview($files);
			$view = $config['constants']['ALBUMVIEW'];
		}
		else
			$data = listview($files, $config['constants']['LISTVIEW']);
	}

	return(array("data" => $data, "header" => $header, "files" => $files, "view" => $view));
}

/******************************************
 * Browse by categories. Print menu with 
 * available choices, ie artists, albums 
 * etc. 
 ******************************************/  
function category_menu()
{
  global $config, $page_info, $lang;
  
  $selected = $page_info->category;
  $categories = array("folders" => $lang['folders'], "artists" => $lang['artists'], "albums" => "Albums","genres" => "Genres", "playlists" => $lang['playlists']);
  
  foreach($categories as $c => $value)
  {
    $style = ($selected == $config['constants'][strtoupper($c)])? "menu_highlighted" : "menu";
    $html .= "<a href=\"index.php?category=".$config['constants'][strtoupper($c)]."\" name=\"".$value."\" class=\"".$style."\" onkeydownset={filefirst}>".$value."</a>";
    if($count != (count($categories)-1))
      $html .= "&nbsp;&nbsp;|&nbsp;&nbsp;";
    $count++;
  }

  return $html;
}

/******************************************
 * Displayed in the page header to provide 
 * information on library. 
 * eg: mpc stats
 ******************************************/  
function library_info()
{			
	global $lang;
	
    $stats = mpd_command("stats");

	$str .= "<font class=\"title\">".$lang['musiclibrary']."</font><br />";
	$str .= "<font class=\"title2\">".$stats['songs']." ".$lang['songs']."</font><br />";
	$str .= "<font class=\"title2\">".time_to_readable($stats['db_playtime'])."</font></span>";

	return $str;
}

/******************************************
 * Menu shown below listing with options 
 * based on category selected.  
 ******************************************/  
function listing_menu()
{
	global $page_info, $config, $lang;
	
	if($page_info->category != $config['constants']['PLAYLISTS'] && $page_info->category != $config['constants']['NOWPLAYING'] ){
		$str .=	"<a name=\"playall\" href=\"".$config['link']."index.php?".$page_info->path."&pg=".$page_info->pg."&action=playall\" class=\"menu\">".$lang['playall']."</a>"; 
		$str .= "&nbsp;&nbsp;|&nbsp;&nbsp;";	
	}
	$lbl = ($page_info->category == $config['constants']['NOWPLAYING']) ? "<FONT color=\"white\">".$lang['nowplaying']."</FONT>" : $lang['nowplaying'];
	$str .=	"<a href=\"index.php?category=".$config['constants']['NOWPLAYING']."\" class=\"menu\">".$lbl."</a>";
	
	if($page_info->category == $config['constants']['ARTISTS'] && !empty($page_info->listitem) && empty($page_info->album))  //Artists listing
	{ 
		$str .= "&nbsp;&nbsp;|&nbsp;&nbsp;";
		
		if($_SESSION['artistview'] == "songs"){
				$str .=	"<a href=\"javascript: location.replace('index.php?".$page_info->path."&pg=".$page_info->pg."&toggle=albums');\" class=\"menu\">".$lang['viewalbums']."</a>";
		}
		else{
			$str .=	"<a href=\"javascript: location.replace('index.php?".$page_info->path."&pg=".$page_info->pg."&toggle=songs');\" class=\"menu\">".$lang['viewsongs']."</a>";		
		}
	}
	elseif($page_info->category == $config['constants']['NOWPLAYING'])
	{
		$str .= "&nbsp;&nbsp;|&nbsp;&nbsp;";
		$str .= "<a href=\"".$config['link']."index.php?".$page_info->path."&pg=".$page_info->pg."&action=clear\" class=\"menu\">".$lang['clearplaylist']."</a>";
		
		$str .= "&nbsp;&nbsp;|&nbsp;&nbsp;";
		$str .= "<a href=\"javascript:show_save_menu();\" class=\"menu\">".$lang['saveplaylist']."</a>";


	}	

	$str .= "&nbsp;&nbsp;|&nbsp;&nbsp;";
	$str .= "<a href=\"".$config['link']."setup.php?".$page_info->path."&pg=".$page_info->pg."\" name=\"setup\" class=\"menu\">".$lang['setup']."</a>";
						
	return $str;

}

/******************************************
 * When mpd is in playing or pause status,
 * Song information with album art will be 
 * displayed   
 ******************************************/
function now_playing($status)
{	
  global $config, $lang;

	$state = $status['state'];
	if($state == "play" || $state == "pause")
	{
		$time_p = explode(":",$status['time']);
		$song = $status['song'];
		$songinfo = getPlaylistInfo($song);
		$folder = $config['mpd']['mpd_music_path']."/".dirname($songinfo['file']);

		if(is_file($folder."/".$config['album_art']))
			$img .= "<img src=\"http://".$_SERVER['HTTP_HOST']."/stream/file=".htmlentities($folder)."/".$config['album_art']."\" width=\"".($config['relative_size']*85)."\" heigth=\"".($config['relative_size']*85)."\">";
    	else
      		$img .= "<img src=\"".$config['link']."images/music_folder.png\" width=\"".($config['relative_size']*85)."\" heigth=\"".($config['relative_size']*85)."\">";
		
		$string .= "<table cellspacing=\"0\" cellpadding=\"0\" width=\"800\">";
		$string .= "<tr><td rowspan =\"5\" width=\"".($config['relative_size']*100)."\">".$img."</td>";
		
		$string .= "<tr><td><a href=\"".$config['link']."songinfo.php?".$page_info->path."&pg=".$page_info->pg."\" name=\"current_song\" onkeydownset='current_song' onkeyrightset=\"playall\" onkeyupset='playall' TVID=\"INFO\"><font color=\"#CCCCCC\" class=\"title2\">".$songinfo['Title']."</font></a></td></tr>";
		$string .= "<tr><td><font class=\"letters\">".$lang['artist'].": ".$songinfo['Artist']."</font></td></tr>";
		$string .= "<tr><td><font class=\"letters\">".$lang['album'].": ".$songinfo['Album']."</font></td></tr>";
		$string .= "<tr><td><font class=\"letters\">".$lang['tracktime'].": ".time_to_readable($time_p[1])."</font></td></tr>";
		$string .= "</table>";
		
		$string .= "<table width=\"".($config['relative_size']*85)."\" cellspacing=\"0\"><tr>";
		
		
		$percent = floor($time_p[0] * 20 / $time_p[1]);
		for($i=0;$i<20;$i++)
		{
			if($i <= $percent)
				$string .= "<td id=\"TD".$i."\" bgcolor=\"teal-alpha\" height=\"".($config['relative_size']*10)."\"></td>";
			else
				$string .= "<td id=\"TD".$i."\" bgcolor=\"black-alpha\" height=\"".($config['relative_size']*10)."\"></td>";
		}
		
		$string .= "</tr></table>";
	
	} 
	return $string;
}

/******************************************
 * Player shown at the bottom to control
 * basic MPD functions
******************************************/
function showMiniPlayer($status)
{
	global $config, $page_info;
	
	$page = $_SERVER['REQUEST_URI'];
	$page = substr($page,0,strpos($page, ".php")+4);
	$page = substr($page,strrpos($page, "/")+1);
	
	$height = ($config['screensetup'] == "hd")? 25 : 16;

	$str .= "<a name=\"prevlink\" href=\"".$config['link'].$page."?".$page_info->path."&pg=".$page_info->pg."&action=prev\" onkeyupset='playall' onkeyleftset='setup'><img border=\"0\" src=\"".$config['link']."images/prev.png\" ONFOCUSSRC=\"".$config['link']."images/prevmo.png\" height=\"".$height."\"></a>&nbsp;&nbsp;&nbsp;";

	if($status['state'] == "play")
		$str .= "<a href=\"".$config['link'].$page."?".$page_info->path."&pg=".$page_info->pg."&action=pause\" onkeyupset='playall' TVID=\"PLAY\"><img border=\"0\" src=\"".$config['link']."images/playmo.png\" height=\"".$height."\"></a>&nbsp;&nbsp;&nbsp;";
	else
		$str .= "<a href=\"".$config['link'].$page."?".$page_info->path."&pg=".$page_info->pg."&action=mpcplay\" onkeyupset='playall' TVID=\"PLAY\"><img border=\"0\" src=\"".$config['link']."images/play5.png\" ONFOCUSSRC=\"".$config['link']."images/playmo.png\" height=\"".$height."\"></a>&nbsp;&nbsp;&nbsp;";

	if($status['state'] == "pause")
		$str .= "<a href=\"".$config['link'].$page."?".$page_info->path."&pg=".$page_info->pg."&action=mpcplay\" onkeyupset='playall' TVID=\"PLAY\"><img border=\"0\" src=\"".$config['link']."images/pausemo.png\" height=\"".$height."\"></a>&nbsp;&nbsp;&nbsp;";
	else
		$str .= "<a href=\"".$config['link'].$page."?".$page_info->path."&pg=".$page_info->pg."&action=pause\" onkeyupset='playall' TVID=\"PLAY\"><img border=\"0\" src=\"".$config['link']."images/pause5.png\" ONFOCUSSRC=\"".$config['link']."images/pausemo.png\" height=\"".$height."\"></a>&nbsp;&nbsp;&nbsp;";
	
	$str .= "<a href=\"".$config['link'].$page."?".$page_info->path."&pg=".$page_info->pg."&action=stop\" onkeyupset='playall' TVID=\"ESC\"><img border=\"0\" src=\"".$config['link']."images/stop5.png\" ONFOCUSSRC=\"".$config['link']."images/stopmo5.png\" height=\"".$height."\"></a>&nbsp;&nbsp;&nbsp;";
	$str .= "<a href=\"".$config['link'].$page."?".$page_info->path."&pg=".$page_info->pg."&action=next\" onkeyupset='playall' TVID=\"NEXT\"><img border=\"0\" src=\"".$config['link']."images/next5.png\" ONFOCUSSRC=\"".$config['link']."images/nextmo.png\" height=\"".$height."\"></a>&nbsp;&nbsp;&nbsp;";
	$str .= "&nbsp;&nbsp;<img src=\"".$config['link']."images/separator.png\" height=\"".$height."\"/>&nbsp;&nbsp;&nbsp;&nbsp;";
	
	/* Random */
	if($status['random'] == 1)
		$str .= "<a href=\"".$config['link'].$page."?".$page_info->path."&pg=".$page_info->pg."&action=random\" onkeyupset='playall'><img border=\"0\" src=\"".$config['link']."images/shufflemo.png\" height=\"".$height."\"></a>&nbsp;&nbsp;&nbsp;";
	else	
		$str .= "<a href=\"".$config['link'].$page."?".$page_info->path."&pg=".$page_info->pg."&action=random\" onkeyupset='playall'><img border=\"0\" src=\"".$config['link']."images/shuffle5.png\" ONFOCUSSRC=\"".$config['link']."images/shufflemo.png\" height=\"".$height."\"></a>&nbsp;&nbsp;&nbsp;";
		
	/* Repeat */
	if($status['repeat'] == 1)
		$str .= "<a href=\"".$config['link'].$page."?".$page_info->path."&pg=".$page_info->pg."&action=repeat\" onkeyupset='playall'><img border=\"0\" src=\"".$config['link']."images/repeatmo.png\" height=\"".$height."\"></a>";
	else
		$str .= "<a href=\"".$config['link'].$page."?".$page_info->path."&pg=".$page_info->pg."&action=repeat\" onkeyupset='playall'><img border=\"0\" src=\"".$config['link']."images/repeat5.png\" ONFOCUSSRC=\"".$config['link']."images/repeatmo.png\" height=\"".$height."\"></a>";
		
	return $str;
}


/******************************************
 * Displayed in the header when inside a 
 * listitem. Shows information about the 
 * selected item.   
 ******************************************/  
function listitem_info($foldername, $songlist)
{	
	global $config, $page_info, $lang;
	$foldername = (strlen($foldername) > 40)? substr($foldername,0,40)."..." : $foldername;
	
	// MPD accepts our constants value as search type
	// as long as it is lowerstring and without the trailing 's'
  $current = array_keys($config['constants'], $page_info->category);
  $cat_val = strtolower($current[0]);
  $cat_val = substr($cat_val,0, strlen($cat_val)-1);
  	
	$c = get_file_count($cat_val, $foldername);
	$filecount	= $c['songs'];
	$playtime	= time_to_readable($c['playtime']);
		
	$nb_dirs = count($songlist);
	
	$html =      "<table cellspacing=\"0\" cellpadding=\"0\" border=\"0\"><tr>";
	
	// If album item selected, display Album art, if any
	if($page_info->category == $config['constants']['ALBUMS']){
		$folder = get_album_path($foldername);	
		if(is_file($folder."/".$config['album_art']))
			$html .=   "<td width=\"".($config['relative_size']*110)."\"><img src=\"http://".$_SERVER['HTTP_HOST']."/stream/file=".htmlentities($folder)."/".$config['album_art']."\" width=\"".($config['relative_size']*100)."\" heigth=\"".($config['relative_size']*100)."\"></td>";
	}
	
	$html .=       "<td valign=\"top\" class=\"albuminfo\">";
	$html .=         "<font class=\"title\">".$foldername."</font><br />";
	
	if($nb_dirs == 1)
		$html .=       "<font class=\"title2\">1 ".$lang['song'].", ".$playtime."<br /></td>";

	elseif($nb_dirs > 1)	
		$html .=       "<font class=\"title2\">".$nb_dirs." ".$lang['songs'].", ".$playtime."<br /></td>";
		
	$html .=      "</tr></table>";
		
	return $html;	
}


function folder_info($foldername, $songlist)
{	
	global $config, $page_info, $lang;
	$displayname = (strlen($foldername) > 80)? substr($foldername,0,80)."..." : $foldername;
	$displayname = basename($foldername);
	
	// MPD accepts our constants value as search type
	// as long as it is lowerstring and without the trailing 's'
  $current = array_keys($config['constants'], $page_info->category);
  $cat_val = strtolower($current[0]);
  $cat_val = substr($cat_val,0, strlen($cat_val)-1);

	$nb_dirs = $page_info->folder_count;
	$nb_files = $page_info->file_count; 
	
	$html =      "<table cellspacing=\"0\" cellpadding=\"0\" border=\"0\"><tr>";
	
	// If album item selected, display Album art, if any
	if(is_dir($config['mpd']['mpd_music_path']."/".$foldername)){
		$albumart = $config['mpd']['mpd_music_path']."/".$foldername."/".$config['album_art'];	
		if(is_file($albumart))
			$html .=   "<td width=\"".($config['relative_size']*110)."\"><img src=\"http://".$_SERVER['HTTP_HOST']."/stream/file=".$albumart."\" width=\"".($config['relative_size']*100)."\" heigth=\"".($config['relative_size']*100)."\"></td>";
	}
	
	$html .=       "<td valign=\"top\" class=\"albuminfo\">";
	$html .=         "<font class=\"title\">".$displayname."</font><br />";
	
	if($nb_dirs == 1)
		$html .=       "<font class=\"title2\">1 ".$lang['folder']."<br /></td>";
	elseif($nb_dirs > 1)	
		$html .=       "<font class=\"title2\">".$nb_dirs." ".$lang['folders']."<br /></td>";
		
	if($nb_files == 1)
		$html .=       "<font class=\"title2\">1 ".$lang['song']."<br /></td>";
	elseif($nb_files > 1)	
		$html .=       "<font class=\"title2\">".$nb_files." ".$lang['songs']."<br /></td>";

		
	$html .=      "</tr></table>";
		
	return $html;	
}


function album_info($files)
{	
	global $page_info, $lang, $config;
	
	$album = urldecode(stripslashes($page_info->album));
	$artist = $page_info->listitem;
	if(strlen($artist) > 30)
		$artist = substr($artist,0,30);
		
	$html = "";
	$nb_dirs = count($files);
		
	$folder = get_album_path($album);

	$html = "<table cellspacing=\"0\" cellpadding=\"0\" border=\"0\"><tr>";
	
	if(is_file($folder."/".$config['album_art']))
		$html .= "<td width=\"".($config['relative_size']*110)."\"><img src=\"http://".$_SERVER['HTTP_HOST']."/stream/file=".htmlentities($folder)."/".$config['album_art']."\" width=\"".($config['relative_size']*100)."\" heigth=\"".($config['relative_size']*100)."\"></td>";
	
	$html .= "<td valign=\"top\" class=\"albuminfo\">";
	$html .= "<font class=\"title\">".$album."</font><br />";
	$html .= "<font class=\"title2\">".$artist."</font><br />";
	
	if($nb_dirs == 1)
		$html .= "<font class=\"title2\">1 ".$lang['song']."</td>";

	elseif($nb_dirs > 1)	
		$html .= "<font class=\"title2\">".$nb_dirs." ".$lang['songs']."</td>";
		
	$html .= "</tr></table>";
		
	return $html;
	
}

function artist_album_infos($files)
{
	global $config, $page_info;
	
	$html = "";
	$nb_albums = count($files);
	
	// MPD accepts our constants value as search type
	// as long as it is lowerstring and without the trailing 's'
	$current = array_keys($config['constants'], $page_info->category);
	$cat_val = strtolower($current[0]);
	$cat_val = substr($cat_val,0, strlen($cat_val)-1);

	$c = get_file_count($cat_val, $page_info->listitem);
	$filecount	= $c['songs'];
	$playtime	= time_to_readable($c['playtime']);
	
	$html = "<table cellspacing=\"0\" cellpadding=\"0\" border=\"0\"><tr>";
	$html .= "<td valign=\"top\" class=\"albuminfo\">";
	if(strlen($page_info->listitem) > 40)
		$html .= "<marquee><font size=\"7px\">".$page_info->listitem."</font></marquee><br />";
	else
		$html .= "<font class=\"title\">".$page_info->listitem."</font><br />";
	
	if(!($_SESSION['artistview'] == "songs")){
		if($nb_albums == 1)
			$html .= "<font class=\"title2\">1 Album<br />";
		elseif($nb_albums > 1)	
			$html .= "<font class=\"title2\">".$nb_albums." Albums<br />";
	}
	
	if($filecount == 1)
		$html .= "<font class=\"title2\">1 Song, ".$playtime."<br />";
	elseif($filecount > 1)	
		$html .= "<font class=\"title2\">".$filecount." Songs, ".$playtime."<br />";
	
	$html .= "</td></tr></table>";
		
	return $html;
}

?>
