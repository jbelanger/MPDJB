<?php

function parse_actions()
{
	global $config, $page_info;

	$action = $page_info->action;
	$param = str_replace("\"", "\\\"", stripslashes($page_info->param));
		
	//TVID have preseance over other actions
	if(!empty($page_info->tvidaction))
  	{
		switch($page_info->tvidaction)
    	{
		case "add":
			
			$selecteditem = $_GET['what'];
			
			if($selecteditem == "song"){
				if(strpos($param, "');"))
				$param = str_replace("');", "", $param);
				
				$result = add_song($param, false);
			}
			elseif($selecteditem == "list")
			{
				if($page_info->category == $config['constants']['FOLDERS'])
				{
					$str = urldecode($_SERVER['REQUEST_URI']);
					$str = substr($str,strpos($str,"tvidref=")+8);
					$str = substr($str,strpos($str,"listitem="));
					$str = substr($str,9);						
					$str = strtok($str,"&");
				}
				else{
					$str = urldecode($_SERVER['REQUEST_URI']);
					$str = substr($str,strpos($str,"listitem="));
					$str = substr($str,9);						
					$str = strtok($str,"&");
				}
				$result = add_list(urldecode(stripslashes($str)), $page_info->category, false);
			}
			elseif($selecteditem == "album"){
				if($page_info->category == $config['constants']['ARTISTS'])
				{
					$str = urldecode($_SERVER['REQUEST_URI']);
					$str = substr($str,strpos($str,"album="));
					$str = substr($str,6);						
					$str = strtok($str,"&");
					$result = add_list(stripslashes($str), $config['constants']['ARTISTS'], false);
				}
				else
				{
					$str = urldecode($_SERVER['REQUEST_URI']);
					$str = substr($str,strpos($str,"listitem="));
					$str = substr($str,9);						
					$str = strtok($str,"&");	
					$result = add_list(urldecode(stripslashes($str)), $config['constants']['ALBUMS'], false);
				}	
			}
			break;
			case "delete":
				$result = execute("del", $page_info->param);
				break;
			}
	}
	else{
		switch ($action) {
		    case "play": 
		    	if($_GET['what'] == "song"){
					$result = add_song($param, true);
				}
				else{
					$result = add_list(urldecode(stripslashes($param)), $page_info->category, true);
					}
				break; 
		    case "mpcplay":
				$result = execute("play");
		    	break;
		    case "playindex":
		    	$result = execute("play", $param);
		    	break;
		    case "stop":
		        $result = execute("stop");
		        break;
		    case "pause":
		        $result = execute("pause");
		        break;
		    case "clear":
				$result = execute("clear");
		    	break;
		   	case "next":
		   		$result = execute("next");
		   		break;
		   	case "prev":
		   		$result = execute("prev");
		   		break;
		   	case "random":
		   		$result = execute("random");
		   		break;
			case "repeat":
		   		$result = execute("repeat");
		   		break;
		   	case "playall":
		   		$result = playAll();
		   		break;
		   	case "load":
		   		execute("clear");
		   		$result = execute("load", $param);
				execute("play");
		   		break;
		   	case "save":
		   		execute("playlist");
		   		$result = execute("save", $param);				   	
				destroy_session();			   		   		
		   		break;
		   	case "update":
		   		$result = execute("update");	
		   		break;
		}	
	}
		
	if(!empty($page_info->action) || !empty($page_info->tvidaction))
	{	
		$host  = $_SERVER['HTTP_HOST'];
		$uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
		$extra = basename($_SERVER['PHP_SELF'])."?".$page_info->path."&pg=".$page_info->pg;
		echo "<script>location.replace(\"http://".$host.$uri."/".$extra."\");</script>";		
	}
	
	return $result;
}

function execute($action, $param="")
{	
	$result = "";
	
	if($param != "")
		$cmd = $action." \"".$param."\"";
	else
		$cmd = $action;
	
	exec("mpc ".$cmd, $result);
	if(strpos($result, "ACK"))
	{
		// Error
		$cmd .= " - Failed";
	}
	else{
		// OK
		$cmd .= " - OK";
	}
	
	return $cmd;
}

function get_mpd_handle()
{
	global $config;
	$host = $config['mpd']['host'];
	$port = $config['mpd']['port'];
	
	//Make connection to Music Player Deamon	
	$fp = @fsockopen($host,$port,$errno,$errstr,10);
	if(!$fp) {
		echo "$errstr ($errno)<br>\n";
		return;
	}
	while(!feof($fp)) {
			$got =  fgets($fp,1024);
			if(strncmp("OK",$got,strlen("OK"))==0) 
				break;
			print "$got<br>";
			if(strncmp("ACK",$got,strlen("ACK"))==0) 
				break;
		}
		if(isset($password)) {
			fputs($fp,"password \"$password\"\n");
			while(!feof($fp)) {
				$got =  fgets($fp,1024);
				if(strncmp("OK",$got,strlen("OK"))==0)
					break;
				print "$got<br>";
				if(strncmp("ACK",$got,strlen("ACK"))==0) 
					break;
			}
		}
	
	return $fp;
}

/*
* Generic method
* COMMAND IN: mpc action (play, pause...)
* OPTIONAL ARG IN: parameter to command (songname)
*/
function DoAction($command, $arg=" ")
{
	global $fp;

	if(!$fp)
	 return;

	if($arg != " ")
		fputs($fp, "$command \"$arg\"\n");
	else
		fputs($fp, "$command\n");
		
	while(!feof($fp)) {
		$got =  fgets($fp,1024);
		$got = preg_replace("/\n/","",$got);
		if(strncmp("OK",$got,strlen("OK"))==0) 
			break;
		if(strncmp("ACK",$got,strlen("ACK"))==0) {
			print "$got<br>\n";
			break;
		}
		
	}
}

function playAll()
{	
	global $config, $page_info;
	
	DoAction("clear");
	
	if(empty($page_info->listitem))
	{
		// Add whole library
		DoAction("add", "/");
	}	
	else
	{
		switch($page_info->category)
		{
			case $config['constants']['FOLDERS']:
				$result = execute("add", $page_info->listitem);
				break;
			case $config['constants']['ARTISTS']:
				if(!empty($page_info->album))
					$find = "album \"".$page_info->album."\" artist \"".$page_info->listitem."\"";				
				else
					$find = "artist \"".$page_info->listitem."\"";
				$result = execute("list filename ".$find." | mpc add", $ret);
				break;
			case $config['constants']['ALBUMS']:
				$find = "album \"".$page_info->listitem."\"";
				$result = execute("list filename ".$find." | mpc add", $ret);
				break;
			case $config['constants']['GENRES']:
				$find = "genre \"".$page_info->listitem."\"";
				$result = execute("list filename ".$find." | mpc add", $ret);
				break;
			case $config['constants']['PLAYLISTS']:
				$result = execute("load \"".$page_info->listitem."\"");
				break;
			default:
				break;
		}
	}
	
	DoAction("play");
	
	return $result;
}


function add_song($arg, $clear_playlist=false)
{	
	global $page_info, $config;
	if($page_info->category == $config['constants']['NOWPLAYING']){
		$arg = substr($arg,strpos($arg," - ")+3);
		$clear_playlist=false;
	}
	
	//Add selected song to new list(1 element)
	if(!($page_info->category == $config['constants']['FOLDERS']))
		$arg = get_file_path($arg);
		
	if(!empty($arg))
	{
		//First, clear current playlist
		if($clear_playlist)
			DoAction("clear");
		//var_dump($arg);
		$result = execute("add", $arg);	
		DoAction("play");
	}
	
	return $result;
}

function add_list($arg, $category, $clear_playlist=false)
{
	global $config, $page_info;

	if($clear_playlist)
		DoAction("clear");
		
	switch($category)
	{
		case $config['constants']['FOLDERS']:
			$result = execute("add \"".$arg."\"");
			break;
		case $config['constants']['ARTISTS']:
			if(!empty($page_info->listitem))
				$find = "album \"".$arg."\" artist \"".$page_info->listitem."\"";				
			else
				$find = "artist \"".$arg."\"";
			$result = execute("list filename ".$find." | mpc add", $ret);
			break;
		case $config['constants']['ALBUMS']:
			$find = "album \"".$arg."\"";
			$result = execute("list filename ".$find." | mpc add", $ret);
			break;
		case $config['constants']['GENRES']:
			$find = "genre \"".$arg."\"";
			$result = execute("list filename ".$find." | mpc add", $ret);
			break;
		case $config['constants']['PLAYLISTS']:
			$result = execute("load \"$arg\"");
			break;
		default:
			break;
	}

	DoAction("play");
	
	return $result;
}

function get_album_path($album)
{
	global $config;
	
	$conn = get_mpd_handle();
	fputs($conn,"find album \"$album\"\n");
	while(!feof($conn)) {
		$got =  fgets($conn,1024);
		$got = preg_replace("/\n/","",$got);
		if(strncmp("OK",$got,strlen("OK"))==0) 
			break;
		if(strncmp("ACK",$got,strlen("ACK"))==0) {
			print "$got<br>";
			break;
		}
		$el = strtok($got,":");
		if(0==strcmp($el,"file")) {
			$ret = preg_replace("/^$el: /","",$got);
			$ret = $config['mpd']['mpd_music_path']."/".dirname($ret);
			break;
		}		
	}
	
	fclose($conn);
	return $ret;
}

function get_file_path($filename)
{
	exec("mpc find title \"".$filename."\"", $ret);
	return $ret[0];
}

function getStatusInfo() {

	global $fp;
	if(!$fp)
	 return;
	 
	fputs($fp,"status\n");
	while(!feof($fp)) {
		$got =  fgets($fp,1024);
		$got = preg_replace("/\n/","",$got);
		if(strncmp("OK",$got,strlen("OK"))==0) 
			break;
		if(strncmp("ACK",$got,strlen("ACK"))==0) {
			print "$got<br>";
			break;
		}
		$el = strtok($got,":");
		$ret["$el"] = strtok("\0");
		$ret["$el"] = preg_replace("/^ /","",$ret["$el"]);
	}
	if(!isset($ret)) $ret = array();

	return $ret;
}

function get_file_count($type, $value)
{
	global $fp;
	if(!$fp)
	 return;
	 
	$ret = array();
	
	fputs($fp,"count $type \"$value\"\n");

	while(!feof($fp)) {
		$got =  fgets($fp,1024);
		$got = preg_replace("/\n/","",$got);

		if(strncmp("OK",$got,strlen("OK"))==0) 
			break;
		if(strncmp("ACK",$got,strlen("ACK"))==0) {
			print "$got<br>\n";
			break;
		}
		$el = strtok($got,":");
		if(0==strcmp($el,"songs")) 
			$ret['songs'] = preg_replace("/^$el: /","",$got);
		elseif(0==strcmp($el,"playtime")) 
			$ret['playtime'] = preg_replace("/^$el: /","",$got);		
	}

	return $ret;

}

function mpd_command($command)
{	
	global $fp;
	
	if(!$fp)
	 return;

	$ret = array();
	
	fputs($fp,$command."\n");

	while(!feof($fp)) {
		$got =  fgets($fp,1024);
		$got = preg_replace("/\n/","",$got);

		if(strncmp("OK",$got,strlen("OK"))==0) 
			break;
		if(strncmp("ACK",$got,strlen("ACK"))==0) {
			print "$got<br>\n";
			break;
		}
		$el = strtok($got,":");		
		$ret["$el"] = preg_replace("/^$el: /", "", $got);
	}

	return $ret;
}

function get_list($what, $match = " ", $sort=false)
{
	if($what == "folder")
		exec("mpc ls ".$match."",$ret);
	else
		exec("mpc list ".$what." ".$match."",$ret);
	
	if($sort)
		sort($ret);
		
	return $ret;
}

function getLsInfo($command) 
{
  global $fp;
	if(!$fp)
	 return;
	fputs($fp, $command."\n");
	$mcount = -1;
	$dcount = 0;
	$pcount = 0;
	while(!feof($fp)) {
		$got =  fgets($fp,1024);
		$got = preg_replace("/\n/","",$got);
		if(strncmp("OK",$got,strlen("OK"))==0) 
			break;
		if(strncmp("ACK",$got,strlen("ACK"))==0) {
			print "$got<br>\n";
			break;
		}
		$el = strtok($got,":");
		if(0==strcmp($el,"directory")) {
			$dir[$dcount] = preg_replace("/^$el: /","",$got);
			$dcount++;
			continue;
		}
		if(0==strcmp($el,"playlist")) {
			$playlist[$pcount] = preg_replace("/^$el: /","",$got);
			$pcount++;
			continue;
		}
		if(0==strcmp($el,"file")) {
			if($mcount>=0) 
			//$music[$mcount] = setNotSetSongFields($music[$mcount]);
			$mcount++;
		}
		$music[$mcount]["$el"] = preg_replace("/^$el: /","",$got);
	}
	if(!isset($dir)) $dir = array();
	if(!isset($music)) $music = array();
	if(!isset($playlist)) $playlist = array();
	$ret["dir"] = $dir;
	$ret["music"] = $music;
	$ret["playlist"] = $playlist;

	return $ret;
}

// Folder View
function getFolders()
{
	$ret = getLsInfo();
}



?>