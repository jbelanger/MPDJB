<?php

//-----------------------------------------------
// Display items like in the Windows Explorer in
// Detailed view. Listing is from top-to-bottom 
// spanned on numbers of columns/rows specified
// in config.
//-----------------------------------------------
function listview($files, $view)
{
	global $filefirst, $config, $page_info;
	
	$filesAreaWidth 	= $config['filesAreaWidth'];
	$nbRows 			= $config['listview_rows'];
	$nbColumns 			= $config['listview_columns'];
	$maxFiles 			= $nbRows * $nbColumns;
	
	$filefirst = "";
	$num = count($files);
	
	if($num <= 0)
		return;
	
	$pg = $page_info->pg;
	
	$from = ($maxFiles * $pg);
	$to = $from + $maxFiles;
	
	if ($to > $num) 
		$to = $num;
	
	$item = 1;
	
	// Determine columns width based on number of items
	$width = $filesAreaWidth;
	$c = $nbColumns;
	$nbItems = ($num <= $maxFiles)? $num : $to - $from;
	while((($nbItems/$c) <= $nbRows))
	{		
		$width = floor($filesAreaWidth / $c);
		$c--;
		if($c == 0)
			break;
	}

	$rowheight = ceil($config['filesAreaHeight']/$nbRows);
	
	if($page_info->category == $config['constants']['NOWPLAYING']){
	  	$tvid_del_link = ($view == $config['constants']['SONGVIEW'])? $config['link']."index.php?".$page_info->path."&pg=".$page_info->pg."&what=song&tvidaction=delete&tvidref=" : $config['link']."index.php?".$page_info->path."&pg=".$page_info->pg."&what=list&tvidaction=add&tvidref=";
		$html .= "<a href=\"".$tvid_del_link."\" TVID=\"_CLEAR\"></a>";
	}
	else{
	  	$tvid_add_link = ($view == $config['constants']['SONGVIEW'])? $config['link']."index.php?".$page_info->path."&pg=".$page_info->pg."&what=song&tvidaction=add&tvidref=" : $config['link']."index.php?".$page_info->path."&pg=".$page_info->pg."&what=list&tvidaction=add&tvidref=";
		$html .= "<a href=\"".$tvid_add_link."\" TVID=\"_URL\"></a>";
	}
	
	$html .= "<a href=\"#{filefirst}\" ONFOCUSSET=\"{filefirst}\"></a>";
	$html .= "<table cellpadding=\"0\" cellspacing=\"0\" width=\"100%\" height=\"".$config['filesAreaHeight']."\">";          
	$html .= 	"<tr><td height=\"".($rowheight/4)."\">&nbsp;</td></tr>";
	$html .= 	"<tr>";
	$html .=		"<td width=\"10\"></td>";
	$html .= 		"<td width=\"".($width-10)."\" valign=\"top\" align=\"left\" >";
	$html .= 			"<table cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">";
	
	for ($n = $from; $n<$to; $n++) 
	{	
		if ($n>=$num)
			break; 
		
		$FILE_INDEX = (($n+1) < 10) ? "0".($n+1) : ($n+1); 
		
		$table_data = get_table_values($files[$n], $view, $FILE_INDEX);
		$filelast = $FILE_INDEX;
		$filefirst = ($filefirst == "") ? $FILE_INDEX : $filefirst;
					
		$html .=				"<tr>";
		$html .=					"<td valign=\"top\" align=\"left\" height=\"".$rowheight."\">";
		$html .=						"<table cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" class=\"listitem\">";
		$html .= 							"<tr>";
		//$html .= 								"<td align=\"left\" width=\"".$rowheight."\">".$FILE_INDEX."</td>";

		if(!empty($table_data['type']))
			$html .=							"<td width=\"".$rowheight."\"><IMG src=\"".$config['link']."images/list_".$table_data['type'].".png\" width=\"".($rowheight)."\" height=\"".($rowheight-5)."\"></td>";
  
		$html .= 								"<td align=\"left\">";
		$html .= 									"<a href=\"".$table_data['href']."\" name=\"".$FILE_INDEX."\" "; 
		
		if ($n == $from ) 
			$html .= 								"onkeyupset='artist' "; 
		
		if (floor(($item-1) / $nbRows) == ($nbColumns -1)) 
			$html .=								"onkeyrightset='pgdn' ";
		
		if($item % $nbRows == 0)
			$html .=								"onkeydownset='playall' ";
			
		if($item <= $nbRows)
			$html .=								"onkeyleftset='pgup' ";
		
		// Try to limit the number of HTML tag because the Gaya browser does not support lots of tags and display problems occurs when a lot of items
		if(strlen($table_data['name']) >= 25)
			$html .= 								"tvid=\"".$FILE_INDEX."\"><marquee behavior=\"FOCUS\">".$table_data['name']."</a></marquee></td>";	
		else
			$html .= 								"tvid=\"".$FILE_INDEX."\">".$table_data['name']."</a></td>";	
				
		$html .=							"</tr>";
		$html .=						"</table>";
		
		/*-- NEXT --*/ 
		$html .=					"</td>";
		$html .=				"</tr>\n";
		
		
		if (fmod($n+1, $nbRows) == 0 && ($n+1) != $num && (($n+1) % $maxFiles) !== 0){		
			$html .=			"</table>";
			$html .=		"</td>\n";
			$html .=		"<td width=\"20\"></td>";
			$html .=		"<td width=\"".$width."\" valign=\"top\" align=\"left\" height=\"".($config['filesAreaHeight'] - ($rowheight/2))."\">";
			$html .=			"<table cellspacing=\"0\" cellpadding=\"0\" width=\"100%\">";			
		}
		
		$item += 1;
	} //End For
	
	/*-- ENDLISTING --*/ 
	$html .= 				"</table>";
	$html .= 			"</td>";
	$html .=		"</tr>";
	$html .= 	"<tr><td height=\"".($rowheight/4)."\">&nbsp;</td></tr>";
	$html .=	"</table>";
	
	// Previous page link
	if ($pg > 0) { 
		$html .= 			"<a name=\"pgup\" onkeyrightset=\"pgdn\" href=\"javascript: location.replace('".$table_data['prevpage']."')\" tvid=\"PGUP\" ONFOCUSLOAD></a>";
	} 
	
	// Next page link
	if ($to < $num) { 
		$html .= 			"<a name=\"pgdn\" onkeyleftset=\"pgup\" href=\"javascript: location.replace('".$table_data['nextpage']."')\" tvid=\"PGDN\" ONFOCUSLOAD></a>";
	}

	return $html;
}

function albumview($files)
{
	global $filefirst, $config, $page_info;
	
	$num = count($files);
	$table_display = compute_albumview($num);
	
	$filesAreaWidth 	= $config['filesAreaWidth'];
	$nbRows 			= $table_display['rows'];
	$nbColumns 			= $table_display['columns'];
	$iconsize			= $table_display['icon_size'];
	$td_height			= $table_display['td_height'];
	$maxFiles 			= $nbRows * $nbColumns;//$config['nb_albums'];
		
	$filefirst = "";
		
	if($num <= 0)
		return;
	
	$pg = $page_info->pg;
	
	$from = ($maxFiles * $pg);
	$to = $from + $maxFiles;
	
	if ($to > $num) 
		$to = $num;
		
	$item = 1;
	
	$width = round($filesAreaWidth / $nbColumns);
	$tvid_add_link = $config['link']."index.php?".$page_info->path."&pg=".$pg."&what=album&tvidaction=add&tvidref=";
	
	$html  = "<a href=\"#{filefirst}\" ONFOCUSSET=\"{filefirst}\"></a>";
	$html .= "<a href=\"".$tvid_add_link."\" TVID=\"_URL\"></a>";
	$html .= "<table cellspacing=\"0\" width=\"".$config['filesAreaWidth']."\" height=\"".$config['filesAreaHeight']."\">";   

	if($config['albummode'] == 2)
		$html .= 	"<tr><td height=\"".(10*$config['relative_size'])."\">&nbsp;</td></tr>";       

	$html .= 	"<tr>";
	$html .= 		"<td width=\"".$width."\" valign=\"top\" align=\"left\">";
	
	for ($n = $from; $n<$to; $n++) 
	{		
		if ($n>=$num)
		break; 
		
		$FILE_INDEX = (($n+1) < 10) ? "0".($n+1) : ($n+1); 
		
		$filename = $files[$n];
		$filelast = $FILE_INDEX;
		$filefirst = ($filefirst == "") ? $FILE_INDEX : $filefirst;
		
		$item_name = urlencode($filename);
	
		$table_data = get_table_values($filename, $config['constants']['ALBUMVIEW'], $FILE_INDEX);

		$album_path = get_album_path($filename);
		if(file_exists($album_path."/".$config['album_art']))
			$fileicon = "http://".$_SERVER['HTTP_HOST']."/stream/file=".htmlentities($album_path)."/".$config['album_art'];
		else
		{
			$fileicon = $config['link']."images/music_folder.png";
		}
		
		if($config['albummode'] == 1)
			$filename =	str_replace("'","",$filename);
		else{
		
			$filename = wordwrap($filename, 10, "<br />", true);
			$parts = explode("<br />",$filename);
			$filename = implode("<br />",array($parts[0],$parts[1],$parts[2]));
			if($parts[3] != NULL)
				$filename .= "...";
		}
		
        $html .= 		"<table cellspacing=\"0\" width=\"".$width."\">";
        $html .= 			"<tr>";
		$html .= 				"<td valign=\"top\" align=\"center\" height=\"".($td_height)."\">";
		
		if($config['albummode'] == 2)
		{
			$html .=				"<img src=\"".$fileicon."\" height=\"".$iconsize."\" width=\"".$iconsize."\">";
			$html .= 				"<br>";
		}
		
		$html .= 					"<a href=\"".$table_data['href']."\" name=\"".$FILE_INDEX."\" "; 
		
		if ($n == $from ) 
			$html .= 					"onkeyupset='artists' "; 
		if ($item == 1 || ($item-1) % $nbColumns == 0) 
			$html .= 					"onkeyleftset='pageup' ";
		if ($item > ($maxFiles - $nbColumns) || ($to - $from) <= $nbColumns) 
			$html .= 					"onkeydownset='playall' ";
		if($item % $nbColumns == 0) {
			$html .= 					"onkeyrightset='pagedn' ";
		}
		
		if($config['albummode'] == 1)
		{
			$html .=					"onfocus=\"javascript:album_hover('".htmlentities($filename, ENT_QUOTES, "UTF-8")."', '".($iconsize-15)."', 'IMG".$FILE_INDEX."');\" ";
			$html .=					"onblur=\"javascript:album_onblur('".$iconsize."', 'IMG".$FILE_INDEX."');\" ";
			$html .= 					"><img id=\"IMG".$FILE_INDEX."\" src=\"".$fileicon."\" height=\"".$iconsize."\" width=\"".$iconsize."\" border=\"0\">";
		}
		else
			$html .= 					"><font class=\"albumitem\">".$filename."</font>";

		$html .=					"</a><br>";
		$html .= 				"</td>";
		$html .= 			"</tr>";
		$html .= 		"</table>";
		
		//-- NEXT --
		$html .= 	"</td>";
		
		if (fmod($n+1, $nbColumns) == 0 && ($n+1) != 0){
			$html .= "</tr>";
			$html .= "<tr>";
		}
		
		$html .= "<td valign=\"top\">";
		
		$item += 1;
	} //End For

	/*-- ENDLISTING --*/ 
	$html .= "</td>";
	$html .= "</tr>";
	$html .= "</table>";
	
	if($config['albummode'] == 1){
		$html .= "<HR color=\"black-alpha2\">";
		$html .= "<div align=\"center\" id=\"albumname\" class=\"album_name\">.</div>";
	}

	$p	= ($pg > 0) ? $pg-1 : intval(count($files)/$maxFiles);
	
	//Previous page link
	if ($pg > 0) { 
		$html .= "<a name=\"pageup\" onfocusload href=\"javascript: location.replace('".$config['link']."index.php?".$page_info->path."&pg=".$p."')\" tvid=\"PGUP\"></a>";
	}   
	
	if ($to < $num) { 
		$html .= "<a name=\"pagedn\" onfocusload href=\"javascript: location.replace('".$config['link']."index.php?".$page_info->path."&pg=".($pg+1)."')\" tvid=\"PGDN\"></a>";
	}

	return $html;
}

function compute_albumview($num)
{

	global $config, $page_info;
	
	$pg = $page_info->pg;
	
	$from = ($config['nb_albums'] * $pg);
	$to = $from + $config['nb_albums'];
	
	if ($to > $num) 
		$to = $num;
		
	$number_of_items = $to - $from;
	
	$ret = array();
	
	if($config['albummode'] == 2)
	{
		$ret['rows'] = 2;
		$ret['columns'] = 8;
		$ret['icon_size'] = $config['relative_size'] * 110;
		$ret['td_height'] = 160;
	}
	else
	{
		if($config['nb_albums'] > 14)
		{
			$ret['rows'] = 3;
			$ret['columns'] = 10;
			$ret['icon_size'] = ($config['relative_size'] * 300) / $ret['rows'];
			//if($number_of_items <= 10)
				$ret['td_height'] = $ret['icon_size'];
			//elseif($number_of_items <= 20)
			//	$ret['td_height'] = $ret['icon_size'] * ;
		}
		elseif($config['nb_albums'] <= 14)
		{
			$ret['columns'] = 7;
			$ret['rows']	= 2;
			$ret['icon_size'] = ($config['relative_size'] * 300) / $ret['rows'];
			$ret['td_height'] = ($number_of_items <= 7)? $ret['icon_size'] * 2 : $ret['icon_size'];
		}
	}

	return $ret;
}

function get_table_values($title, $view, $file_index)
{
	global $config, $page_info;
	$pg = $page_info->pg;
		
	$ret = array();
	$ret['title']		= urlencode($title);
	$ret['name']		= $title;

	switch($view)
	{
	  	/* Listview used to display category listing, 
       	 * ie Browse by: Artist, Album, Genre etc.  */
		case $config['constants']['LISTVIEW']:	
			// Default icon image
			$ret['type'] = "folder";
			
			if($page_info->category == $config['constants']['PLAYLISTS'])
				$ret['href'] 	= $config['link']."index.php?".$page_info->path."&what=song&action=load&param=".$ret['title']."&pg=".$pg;
			elseif($page_info->category == $config['constants']['FOLDERS'])
			{
				$ret['name'] = basename($title);
				
				if(in_array(pathinfo($title,PATHINFO_EXTENSION), $config['filetypes']['audio'])){
					// FILE
					$ret['href'] 	= $config['link']."index.php?".$page_info->path."&what=song&action=play&param=".$ret['title'];
					$page_info->file_count++;
					$ret['type'] = "audio";
				}
				else{
					// FOLDER
					$ret['href'] 	= $config['link']."index.php?category=".$page_info->category."&listitem=".urlencode(stripslashes($ret['title']));
					$page_info->folder_count++;
				}
			}
			else
				$ret['href'] 	= $config['link']."index.php?".$page_info->path."&pg=0&listitem=".urlencode(stripslashes($ret['title']));
				
			$ret['nextpage'] = $config['link']."index.php?".$page_info->path."&pg=".($pg+1)."&filter=".$_GET['filter'];
			$ret['prevpage'] = $config['link']."index.php?".$page_info->path."&pg=".($pg-1)."&filter=".$_GET['filter'];
			
			break;
		/* Songview is used by every category (but folders view) to display song listing */	
		case $config['constants']['SONGVIEW']:	

			$ret['type'] = "audio";

			if($page_info->category == $config['constants']['NOWPLAYING'])
				$ret['href'] 	= $config['link']."index.php?".$page_info->path."&what=song&action=playindex&param=".$file_index;
			else
				$ret['href'] 	= $config['link']."index.php?".$page_info->path."&what=song&pg=".$pg."&action=play&param=".$ret['title'];
			
			$ret['nextpage'] 	= $config['link']."index.php?".$page_info->path."&pg=".($pg+1)."&filter=".$_GET['filter'];
			$ret['prevpage'] 	= $config['link']."index.php?".$page_info->path."&pg=".($pg-1)."&filter=".$_GET['filter'];
			
			break;
		case $config['constants']['ALBUMVIEW']:
			
			// Reset page number when going inside listitem
			$path = substr($page_info->path,0,strpos($page_info->path,"pg=")+3);
			$path .= "0";

			if($page_info->category == $config['constants']['ALBUMS'])
			{
				$ret['href'] = $config['link']."index.php?".$page_info->path."&pg=0&listitem=".$ret['title'];
			}
			else{
				$ret['href'] = $config['link']."index.php?".$page_info->path."&pg=0&album=".$ret['title'];
			}
			
			break;
		default:
			break;
	}

	return $ret;	
}

?>
