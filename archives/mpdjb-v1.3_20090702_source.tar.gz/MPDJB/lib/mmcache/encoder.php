<?php

function mkdir_recursive($pathname, $mode)
{
    is_dir(dirname($pathname)) || mkdir_recursive(dirname($pathname), $mode);
    return is_dir($pathname) || @mkdir($pathname, $mode);
}

function listFiles( $from = '.')
{
    if(! is_dir($from))
        return false;
    
    $files = array();
    $dirs = array( $from);
    while( NULL !== ($dir = array_pop( $dirs)))
    {
        if( $dh = opendir($dir))
        {
            while( false !== ($file = readdir($dh)))
            {
                if( $file == '.' || $file == '..')
                    continue;
                $path = $dir . '/' . $file;
                if( is_dir($path))
                    $dirs[] = $path;
                elseif(pathinfo($path, PATHINFO_EXTENSION)  == "php")
                    $files[] = $path;
            }
            closedir($dh);
        }
    }
    return $files;
}

$ret = listfiles("/share/MPDJB");
mkdir("/share/MPDJB/lib/mmcache/ENC");

foreach($ret as $phpfile)
{
	$dir = dirname($phpfile);
	$file = basename($phpfile);
	mkdir_recursive("/share/MPDJB/lib/mmcache/ENC".$dir,0777);
	$str = "<?php";
	$str .= " if (!is_callable(\"mmcache_load\") && !@dl((PHP_OS==\"WINNT\"||PHP_OS==\"WIN32\")?\"TurckLoader.dll\":\"TurckLoader.so\")) { die(\"This PHP script has been encoded with Turck MMcache, to run it you must install <a href=\\\"http://turck-mmcache.sourceforge.net/\\\">Turck MMCache or Turck Loader</a>\");} return mmcache_load('".mmcache_encode($phpfile)."');";
	

	$str .= "?";
	$str .= ">";
	$handle = fopen("/share/MPDJB/lib/mmcache/ENC/".$phpfile, "w+");
	fwrite($handle, $str);
	
	fclose($handle);
}
echo("Done!!");

?>
