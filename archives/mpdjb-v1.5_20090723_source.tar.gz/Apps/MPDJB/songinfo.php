<?php

/* * * * * * * * * * * * * * * * * * * * * * * * * *\
 * Display Song information.
 * - Cover art if available. 
 * - Metadata info from MPD 
 * - Song remaining time
 * This page is accessed via the Now Playing label
 * in the main interface
 * * * * * * * * * * * * * * * * * * * * * * * * * */

require_once("lib/utils.php");
require_once("lib/config.php");
require_once("lib/template.php");
require_once("lib/library.php");
require_once("lib/mpd.php");
require_once("lib/playlist.php");
//require_once("lib/slideshow.php");

global $config, $fp, $current_song, $lang;

	$starttime = microtime_float();
		
	$songid = (isset($_GET['song']))? $_GET['songid']:0;
	
	// Retrieve required configuration
	init_session();
	read_config();
	$page_info = get_page_info();
	require_once("lib/lang/".$config['language']); 
	
	// MPD 
	$fp = get_mpd_handle();
	parse_actions();
	
	$current_song = mpd_command("currentsong");	
	$status = mpd_command("status");
	$current_song = array_merge($status, $current_song);

	$miniplayer = showMiniPlayer($status);
	$time_parts = explode(":", $status['time']);

	// Song remaining time
	if($status["state"] == "play"){
		$remaining = ($time_parts[1] - $time_parts[0]);
	}
	else{
		// virtually forever
		$remaining = 1000000;
	}

	
	
	// Determine if FanArt Mode or not
	$fanart = get_fanart_image();
	if((empty($fanart) && $config['now_playing_mode'] == 0) || $config['now_playing_mode'] == 2)
	{
		// Page setup
		$page = new Page($config['title_template']);
		$side_menu = "<span id=\"time\" class=\"clock\">.</span>";
			
		$page->replace_tags(array(
		  "title" 		=> "MPDJB",
		  "charset" 	=> $config['charset'],
		  "style" 		=> "style.dat", 
		  "background" => $config['background'],
		  "menu" 		=> "",
		  "miniplayer" => $miniplayer,
		  "libraryinfo" => "<a href=\"javascript:history.go(-1);\"><img border=\"0\" src=\"".$config['link']."images/prevpage2.png\" onfocussrc=\"".$config['link']."images/prevpagemo.png\" height=\"".(40 *$config['relative_size'])."\" width=\"".(40 *$config['relative_size'])."\"></a>",//$page_data['header'], 
		  "side_menu"	=> $side_menu,
		  "refresh_time" => $remaining,
		  "files" 		=>  get_song_info(),
		));
	
		//$time_parts = explode(":", $current_song['time']);
	}
	else
	{
		if(empty($fanart))
			$fanart = $config['background'];
		// Page setup
		$page = new Page($config['fanart_template']);
		
		$page->replace_tags(array(
		  "title" 		=> "MPDJB",
		  "charset" 	=> $config['charset'],
		  "style" 		=> "style.dat", 
		  "background" => $fanart,
		  "miniplayer" => "<table><tr><td bgcolor=\"black-alpha3\" width=\"300\" height=\"35\" align=\"center\">".$miniplayer."</td></tr></table>",
		  "refresh_time" => $remaining,
		  "files" 		=>  get_song_info_mini(),
		  "time_counter"	=> "<span id=\"time\">.</span>",
  		  "mini_player" => $miniplayer,
  		  //"test"	=>	$config['link']."lib/slideshow.php",

		));
	}

	if($current_song['state'] == "play"){
		$page->page = str_replace("starttime=9999", "starttime=$time_parts[0]", $page->page);
		$page->page = str_replace("endtime=0", "endtime=$time_parts[1]", $page->page);
	}
	elseif($status["state"] == "pause")
	{
		$page->page = str_replace("starttime=9999", "starttime=$time_parts[0]", $page->page);
		$page->page = str_replace("endtime=0", "endtime=$time_parts[0]", $page->page);
	}
		  
	$pagetime = round((microtime_float() - $starttime), 3);        
	$page->page = str_replace("{ms}", $lang['generated'].$pagetime." ".$lang['seconds'], $page->page);
	
	$page->output();

	if($fp)
	  fclose($fp);


function get_song_info()
{
	global $current_song, $config, $lang;
	
	$tags = array(
		"AlbumArtist" 	=> $lang['albumartist'],
		"Genre" 		=> $lang['genre'],
		"Time" 			=> $lang['tracktime'],
		"Date"			=> $lang['year'],
		"Composer" 		=> $lang['composer'],
		"Track" 		=> $lang['track'],
	);
	
	$html .= "<table class=\"textstyle1\">";
	$html .= 	"<tr>";
	$html .= 		"<td width=\"".(300 *$config['relative_size'])."\"><img src=\"".get_album_image($current_song['file'])."\" width=\"".(275 *$config['relative_size'])."\" height=\"".(275 *$config['relative_size'])."\"></td>";
	$html .= 		"<td valign=\"top\">";
	$html .= 			"<b><font class=\"title\">".$current_song['Title']."</font></B><br>";
	$html .= 			"<font class=\"title2\">".$current_song['Artist']."</font><br>";
	$html .= 			"<font class=\"title2\">".$current_song['Album']."</font><br>";
	$html .= 		"</td>";
	$html .= 	"</tr>";
	$html .= 	"<tr><td colspan=\"2\" height=\"10\"></td></tr>";
	$html .= 	"<tr>";
	$html .= 		"<td colspan=\"2\">";
	$html .= 			"<table class=\"textstyle1\">";
	$html .= 				"<tr>";
	
	foreach($tags as $t => $value)
	{
		$tag_data = $current_song[$t];
		if(!empty($tag_data)){
			if($count == 2)
			{
				$html .= 	"</tr>";
				$count = 0;
			}
			if($t == "Time")
				$tag_data = time_to_readable($tag_data);	
			$html .=			"<td width=\"".(400 *$config['relative_size'])."\"><font class=\"listitem\">".$value.": ".$tag_data."</font></td>";
			$count++;
		}			
	}
	
	$html .= ($count == 2)? "</tr>" : "";

	
	if(!empty($current_song['audio'])){
		$parts = explode(":",$current_song['audio']);
		$html .= 				"<td width=\"".(400 *$config['relative_size'])."\"><font class=\"listitem\">".$lang['audio'].": ".$parts[0]." KHz, ".$parts[1]." Bit, ".$parts[2]." ".$lang['channels']."</font></td>";
		$count++;
		$html .= ($count == 2)? "</tr>" : "";
		$html .= 				"<td width=\"".(400 *$config['relative_size'])."\"><font class=\"listitem\">".$lang['bitrate'].": ".$current_song['bitrate']." kbps</font></td>";
	}
	else
	{
		$html .= 				"<td></td>";
	}
	$html .= 				"</tr></table>";
	$html .= 		"</td><td></td></tr>";
	$html .= "</table>";
	
	return $html;		
}

function get_song_info_mini()
{
	global $current_song, $config;
	$nextsong = getPlaylistInfo($current_song['nextsong']);
	
	$html .= "<table cellspacing=\"5\" cellpadding=\"2\" border=\"0\" bgcolor=\"black-alpha3\"><tr><td rowspan=2>&nbsp;</td><td rowspan=2 valign=\"top\" align=\"right\">";
	
	if(!empty($current_song['Title']))
		$html .= "<font class=\"title_white_2\">".$current_song['Title']."</font><BR />";
	else
		$html .= "<font class=\"title_white_2\">".basename($current_song['file'])."</font><BR />";
	
	$html .= "<font class=\"title_white_3\">".$current_song['Album'];

	if(!empty($current_song['Date']))
		$html .= " (".$current_song['Date'].")";

	$html .= "<BR />";
	$html .= $current_song['Artist']."<BR /></FONT>";
	
	if(isset($nextsong['Title'])){
		$html .= "<FONT class=\"title_white_3\" color=\"#B1D3F6\">Next:  </FONT>";
		$html .= "<FONT class=\"title_white_3\" color=\"#847e7e\">".$nextsong['Title']." by ".$nextsong['Artist']."</FONT>";
	}
	$html .= "<hr><p align=\"center\">{mini_player}</p>";
	$end = time_to_readable($current_song['Time']);

	$html .= "</td>";	
	$html .= "<td width=\"".($config['relative_size']*140)."\" align=\"center\" >";
	$html .= "<img src=\"".get_album_image($current_song['file'])."\" width=\"".($config['relative_size']*115)."\" height=\"".($config['relative_size']*115)."\" />";
	
	

	//$html .= "</td></tr><tr><td align=\"center\"></td><td class=\"title_white_3\" align=\"center\">{time_counter} / ".$end;
	$html .= "</td></tr><tr><td align=\"center\" valign=\"middle\" class=\"title_white_3\">{time_counter} / ".$end."</td></tr></table>";
	
	return $html;	
}

function get_album_image2()
{
	global $current_song, $config;
	
	$album_path =  $config['mpd']['mpd_music_path']."/".pathinfo($current_song['file'], PATHINFO_DIRNAME);
	
	if(is_file($album_path."/".$config['album_art']))
		$fileicon = "file://".$album_path."/".$config['album_art'];
	else
		$fileicon = $config['link']."images/music_folder.png";
	
	return $fileicon;
}

function get_fanart_image()
{
	global $config, $current_song;
	
	$bg_img = "";
	$path = $current_song['file'];
	$count =0;
	$imgs = array();
	
	// Get jpg and JPG
	for($i=0;$i<2;$i++){
		
		$path_parts = explode("/", $path);
		unset($path_parts[count($path_parts)-1]);
		$path = implode("/", $path_parts);


		
		$folder_images = glob($config['mpd']['mpd_music_path']."/".$path."/*.jpg");
		$folder_images = array_merge($folder_images, glob($config['mpd']['mpd_music_path']."/".$path."/*.JPG"));
		
		foreach($folder_images as $jpeg)
		{
			$jpeg_size = getimagesize($jpeg);
			if($jpeg_size[0] > 1000)
				$imgs[] = $jpeg;
		}		
	}
	
	
	if(count($imgs) > 0)
		$bg_img = "http://".$_SERVER['HTTP_HOST']."/stream/file=".$imgs[rand(0,count($imgs)-1)];
	
	return $bg_img;		
}

?>
