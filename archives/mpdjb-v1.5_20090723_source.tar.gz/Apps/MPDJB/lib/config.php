<?php

define("DEBUG", false);

class PageInfo
{
  var $path;
  var $pg;
  var $letter;
  var $listitem;
  var $album;
  var $category;
  
  //MPD specific
  var $tvidaction;
  var $action;
  var $param; 
  var $fp;
  
  //vars for folderview
  var $file_count;
  var $folder_count;
  
  var $artistview;
  var $maxFiles;
  var $view;
}

function get_page_info()
{
	global $config;
	
	$page_info = new PageInfo();
	$page_info->pg         		= (isset($_GET['pg'])) ? $_GET['pg'] : 0;
	$page_info->letter			= (isset($_GET['letter'])) ? $_GET['letter'] : "";
	$page_info->listitem   		= stripslashes(urldecode($_GET['listitem']));
	$page_info->album      		= urldecode(stripslashes($_GET['album']));
	$page_info->category   		= isset($_GET['category'])? $_GET['category'] : $config['constants']['FOLDERS'];
	$page_info->tvidaction 		= $_GET['tvidaction'];
	$page_info->action     		= $_GET['action'];
	$page_info->param      		= $_GET['param'];
	$page_info->file_count 		= 0;
	$page_info->folder_count	= 0;
	$page_info->artistview		= $_GET['artistview'];
	$page_info->maxFiles		= 0;
	$page_info->view			= "";

	if(isset($_GET['albumview']))
	{
		$page_info->albumview = $_GET['albumview'];
		$_SESSION['albumview'] = $page_info->albumview;
	}
	elseif(isset($_SESSION['albumview']))
		$page_info->albumview = $_SESSION['albumview'];	
	else
	{
		$page_info->albumview = $config['default_albummode'];
		$_SESSION['albumview'] = $page_info->albumview;
	}
	
	//PATH
	$path = isset($_GET['category'])? "category=".$_GET['category'] : "category=".$config['constants']['FOLDERS'];
	$inAlbum = false;
	$inItem = false;
	if(!empty($page_info->tvidaction)){
		$arr = array();
		$uri = $_SERVER['REQUEST_URI'];		
		$uri = substr($uri, 0 ,strpos($uri,"tvidref="));
		
		$parsed = parse_url($uri);
		$parts = explode("&", $parsed['query']);
		
		foreach($parts as $p)
		{
			if(strncmp($p,"listitem=", strlen("listitem=")) == 0){ 
					$path .= "&".$p;
					$inItem = true;
					if($page_info->category == $config['constants']['FOLDERS']){
	
						if(empty($page_info->param)){
							//Folder selected
							$new = explode("/",$page_info->listitem);	
							unset($new[count($new)-1]);
							$page_info->listitem = implode("/", $new);
						}
					}
			}
		
			if(strncmp($p,"album=", strlen("album=")) == 0){	
				$path .= "&".$p;
				$inAlbum = true;						
			}
			if(strncmp($p,"pg=", strlen("pg=")) == 0){	
				$page_info->pg = substr($p,3);					
			}

		}

		if(!$inItem)
			unset($page_info->listitem);
		elseif(!$inAlbum)
			unset($page_info->album);
	}
	else
	{
		if(isset($_GET['listitem']))
		{
			$path .= "&listitem=".urlencode(stripslashes($_GET['listitem']));
			if(isset($_GET['album']))
				$path .= "&album=".urlencode(stripslashes($_GET['album']));
		}
		else
			$path .= "";
	}
		
	$page_info->path     = $path;
	
	return $page_info;
}


function read_config()
{
  global $config;
    
  if(isset($_SESSION['config']) && DEBUG == false)
    $config 						= $_SESSION['config'];
  else
  {  	
    $config_file 					= parse_ini_file("mpdjb.conf", true);
   
  	$config['charset'] 				= $config_file['main']['charset']; 
  	$config['language'] 			= $config_file['main']['language']; 
  	$config['listview_columns']		= $config_file['main']['listview_columns']; 
  	$config['listview_rows']		= $config_file['main']['listview_rows'];
  	
  	$config['default_albummode']			= $config_file['main']['default_albummode'];
		
  	$config['album_art']			= $config_file['main']['albumart_filename']; 
  	//$config['maxFiles'] 			= $config['listview_columns'] * $config['listview_rows'];
  			
   	$config['background'] 			= "images/background/".$config_file['main']['background'];  	

	$config['TVID']['folders']		= $config_file['tvid']['folders'];
	$config['TVID']['artists']		= $config_file['tvid']['artists'];
	$config['TVID']['albums']		= $config_file['tvid']['albums'];
	$config['TVID']['genres']		= $config_file['tvid']['genres'];
	$config['TVID']['playlists']	= $config_file['tvid']['playlists'];	
	$config['TVID']['update']		= $config_file['tvid']['mpdupdate'];	
	
	// SLIDESHOW
	foreach($config_file['slideshow_folders'] as $folder)
		$folders[] = $folder; 
	$config['slideshow_folders']	= $folders;
	$config['selected_slideshow']	= $config_file['main']['default_slideshow'];
	
	if(!is_file("tmp/slideshow.jsp")) create_playlist("slideshow.jsp");
		
	$config['now_playing_mode']		= $config_file['main']['now_playing_mode'];
	$config['in_gaya']				= (strpos($_SERVER['HTTP_USER_AGENT'],"gaya") > 0)? true : false;
	
	if(DEBUG || $config['in_gaya'])
		$config['link'] 			= ""; 
	else
		$config['link'] 			= "http://".$_SERVER['HTTP_HOST']."/stream/file=".getcwd()."/"; 
		
	$config['app_directory']		= substr($config['link'],0,strpos($config['link'],"MPDJB")+5)."/";
  	
  	$config['screensetup']			= $config_file['main']['screensetup'];
  	$config['template']				= ($config['screensetup'] == "hd")? "templates/template.html" : "templates/template_sd.html";
  	$config['title_template']		= ($config['screensetup'] == "hd")? "templates/template_title.html" : "templates/template_title_sd.html";
  	$config['fanart_template']		= ($config['screensetup'] == "hd")? "templates/template_fanart.html" : "templates/template_fanart_sd.html";
  	$config['relative_size'] 		= ($config['screensetup'] == "hd")? 1 : 0.57;//12/$config['listview_rows']: 20/$config['listview_rows'];
  	$config['filesAreaWidth'] 		= ($config['screensetup'] == "hd")? 1100 : 625;
  	$config['filesAreaHeight'] 		= ($config['screensetup'] == "hd")? 330 : 200;
  	
    $constants = array();
    
    // Categories
    $constants['FOLDERS']       	= "folder";
    $constants['ARTISTS']       	= "artist";
    $constants['ALBUMS']        	= "album";
    $constants['GENRES']        	= "genre";
    $constants['PLAYLISTS']     	= "playlist";    
    $constants['NOWPLAYING']    	= "nowplaying"; 
    
    // Listing views
  	$constants['LISTVIEW']			= 10;
  	$constants['SONGVIEW']			= 11;
  	$constants['ALBUMVIEW']			= 12;
   	
  	$config['constants']			= $constants;
    
    // MPD specific settings 	
  	$config['mpd']            		= parse_mpd_conf();
  	
  	$config['filetypes']['audio'] 	= explode("|","mp3|mp2|wav|aac|wma|pls|m4a|ac3|mp1|mpa|asf|lpcm|pcm|flac");
  	
  	// Cache config
    // Put config in session variable so we don't
    // load the file each time
  	$_SESSION['config'] = $config;
	}

}

/* --------------------------- */
/* Parse mpd.conf for settings */
function parse_mpd_conf()
{
	global $config;
	
	$ret = array();
	
	if(DEBUG)
		exec("ps -ef", $std_out);
	else
		exec("ps", $std_out);
	
	
	foreach($std_out as $line) {
		if(strpos($line, "etc/mpd")) {
			$conf_path = substr($line, strpos($line, "/"), strpos($line, "etc/mpd")+7);
			$conf_path = substr($conf_path, strpos($conf_path, " ")+1);
			break;
		}
	}

	if(empty($conf_path))
	 return;

	$mpd_conf = file($conf_path);

	foreach($mpd_conf as $line)	{
		if($line{0} != '#')	{
			if(strncmp($line,"music_directory",strlen("music_directory"))== 0)
				$ret['mpd_music_path'] = trim(str_replace("\"", "", substr($line, strpos($line,"\"/"))));
				
			if(strncmp($line,"playlist_directory",strlen("playlist_directory"))== 0)
				$ret['mpd_playlist_path'] = trim(str_replace("\"", "", substr($line, strpos($line,"\"/"))));
				
			if(strncmp($line,"port",strlen("port"))== 0)
				$ret['port'] = parseInt(str_replace("port", "", $line));

		}
	}	
	$ret['host'] = "127.0.0.1";
	
	return $ret;
}


?>
