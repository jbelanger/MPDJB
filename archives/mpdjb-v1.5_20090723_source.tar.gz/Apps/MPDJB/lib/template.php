<?php
//global $path, $device, $device_tag, $file_mode;


//require_once("config.php");
//require_once("function.php");

class Page
{
  var $page;

  function Page($template) {
    if (file_exists($template)) {
      //$this->page = join("", file($template));
      $this->page = file_get_contents($template);
    } else {
      die("Template file $template not found.");
    }
  }

  function parse($file) {
  	global $debugLevel;
	if ($debugLevel == 3) {
	        $functionStartTime = microtime_float();
        }
          
    ob_start();
    include($file);
    $buffer = ob_get_contents();
    ob_end_clean();
    
    if ($debugLevel == 3) {
    	echo $file." parsed in ".(microtime_float() - $functionStartTime)." seconds.<br />";
    }
    
    return $buffer;
  }

  function replace_tags($tags = array()) {
    if (sizeof($tags) > 0) {
    	/*
        foreach ($tags as $tag => $data) {
                $data = (file_exists($data)&&(!is_dir($data))) ? $this->parse($data) : $data;
		$this->page = eregi_replace("{" . $tag . "}", $data,
			$this->page);
	}
	*/
        $search = array();
        $replace = array();                                                        
        foreach ($tags as $tag => $data) {
    	  	if (file_exists($data) && (!is_dir($data))) { 
	    	  	$extension = strtolower(substr($data, strlen($data) - 3, 3));
	    	  	if ($extension == "php" || $extension == "dat") { 
      				$data = $this->parse($data);
      			}
	      	}
        	$search[] = '{'.$tag.'}';
	        $replace[] = $data;
      
        }
        
        $this->page = str_replace($search, $replace, $this->page);
        
    }
    else {
      die("No tags designated for replacement.");
    }
  }

  function output() {
    echo $this->page;
  }
}
?>