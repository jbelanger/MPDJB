<?php

/* Ex: MAX_PAGES_TO_SHOW=9 => "<< < 1 2 3 4 5 6 7 8 9 > >>" */
define("MAX_PAGES_TO_SHOW",9);  //Must be Odd number

// Used to calculate page generation time
function microtime_float()
{
    list($usec, $sec) = explode(" ", microtime());
    return ((float)$usec + (float)$sec);
}

function init_session()
{
	session_name("mpdjb");
	
	if(!is_dir("tmp"))
		mkdir("tmp");

	session_save_path("tmp");
		
	if(session_start() == false)
		exit();
}

function destroy_session()
{
	if (isset($_COOKIE[session_name()])) {
		@setcookie(session_name(), '', time()-42000, '/');
	}

	@session_destroy();

}

function time_to_readable($int_time)
{
	global $lang;

	if($int_time > (24*3600)){
		$date = date("z:H:i:s",$int_time);
		$parts = explode(":",$date);
		if($parts[0] == 1)
			$ret = "1 day, ".$parts[1].":".$parts[2].":".$parts[3];
		else
			$ret = $parts[0]." ".$lang['days'].", ".$parts[1].":".$parts[2].":".$parts[3];
	}
	elseif($int_time > 3600){
		$ret = date("h:i:s",$int_time);
	}
	else
		$ret = date("i:s",$int_time);
		  
	return $ret;
}


function pageBrowser($view, $files)
{

  global $page_info;
	
  $begin = floor(MAX_PAGES_TO_SHOW / 2);
  $ends = ceil(MAX_PAGES_TO_SHOW / 2);
  
  global $config, $page_info;
  
	if($view == $config['constants']['ALBUMVIEW'])
	{
		$maxFiles = get_nb_albums_per_page();		
	}
	elseif($view == $config['constants']['SONGVIEW'])
	{
		$maxFiles = 2 * $config['listview_rows'];
	}
	else
		$maxFiles = $page_info->maxFiles;
  
  $link = $config['link'];
   
  $num = count($files);

  if($num > $maxFiles)
  	$pages = intval($num/$maxFiles);
  else
  	return;

  $current_page = $page_info->pg;
 
  // PG=0
  if($current_page == null || $current_page == 0)
    $current_page = 0;
  elseif($current_page > 0)
  {
    if($current_page > $begin)
      $strHTML = "<a href=".$link."index.php?".$page_info->path."&pg=0 onkeydownset='artists'> << </a> "; 
    $prev_page = ($current_page > 0) ? $current_page -1 : 0;
    $strHTML .= "<a href=".$link."index.php?".$page_info->path."&pg=".$prev_page." onkeydownset='artists'> < </a> ";  
  }
  
  for($i=($current_page-$begin);$i<($current_page+$ends);$i++)
  {
    if($i < 0)
      continue;
    elseif($i == ($pages+1))
      break;
    
    $href = $link."index.php?".$page_info->path."&pg=".$i;
    $innerA = ($i == ($pages-1)) ? $i : $i." - ";
    if($current_page == $i)
      $strHTML .= "<a href=".$href." onkeydownset='artists'>&nbsp;<FONT color=\"white\">".($i+1)."</FONT>&nbsp;</a>";
    else
      $strHTML .= "<a href=".$href." onkeydownset='artists'>&nbsp;".($i+1)."&nbsp;</a>";
  }

  if(($current_page)< $pages)
    $strHTML .= "<a href=".$link."index.php?".$page_info->path."&pg=".($current_page+1)." onkeydownset='artists'> > </a> ";
      if(($current_page +$ends) < ($pages+1))


        $strHTML .= "<a href=".$link."index.php?".$page_info->path."&pg=".$pages." onkeydownset='artists'> >> </a> ";
  
  return $strHTML;
}

function show_items_count($view, $files)
{
	global $lang, $config, $page_info;
	
	if($view == $config['constants']['ALBUMVIEW'])
	{
		$maxFiles = get_nb_albums_per_page();		
	}
	elseif($view == $config['constants']['SONGVIEW'])
	{
		$maxFiles = 2 * $config['listview_rows'];
	}
	else
		$maxFiles = $page_info->maxFiles;
	
  	$num = count($files);   
  	$page = ($page_info->pg >= 0) ? $page_info->pg : intval($num/$maxFiles);
  	$page -= ($_GET['goto'] == "Prev") ? 1 : 0;
  	$page += ($_GET['goto'] == "Next") ? 1 : 0;
  	$page = (($maxFiles*$page)+1 > $num) ? 0 : $page;
                                                  
  	$from = ($maxFiles * $page) + 1;
  	$to = $from + $maxFiles - 1;
                                                  
  	if ($to > $num) { $to = $num; }
			      
    return "<font class=\"letters\">".$from." ".$lang['pageto']." ".$to." ".$lang['pageof']." ".$num." ".$lang['pageitems']."</font>";

}

function show_browse_letters($array)
{
  global $config;
  
  $arr = get_start_letters($array);
  $maxFiles = 36;
  foreach($arr as $letter => $value)
  {
    $html .= "<a href=\"".$config['link']."index.php?pg=".floor($value/$maxFiles)."\">".$letter."</a>&nbsp;";
  }
  return $html;
}

function get_start_letters($array)
{
  $len = count($array);
  
  for($i=0;$i<$len;$i++)
  {
    $name = $array[$i];
    $char = strtoupper($name{0});

    if(!$fl[$char])
      $fl[$char] = $i;
  }
  return $fl; 
}

function parseInt($string) {

	if(preg_match('/(\d+)/', $string, $array)) {
		return $array[1];
	} else {
		return 0;
	}
}

function get_album_image($file)
{
	global $config;
	
	$album_path =  $config['mpd']['mpd_music_path']."/".pathinfo($file, PATHINFO_DIRNAME);
	
	if(is_file($album_path."/folder.jpg"))
		$fileicon = "http://".$_SERVER['HTTP_HOST']."/stream/file=".$album_path."/folder.jpg";
	else
		$fileicon = $config['link']."images/music_folder.png";
	
	return $fileicon;
}

function get_page_for_letter($letter, $files)
{
	global $page_info, $config;
	$items_per_page = $page_info->maxFiles;
	$nb_files = count($files);
	$chr_last=0;
	$chr_curr=0;
	$folderview = ($page_info->category == $config['constants']['FOLDERS'])? true : false;
	
	for($index=0;$index<$nb_files;$index++)
	{
		if(is_array($files[$index]))
			continue;
			
		if($folderview)
		{
			$file = basename($files[$index]);
			$next = basename($files[$index+1]);
		}
		else
		{
			$file = $files[$index];
			$next = $files[$index+1];
		}
			
		$chr_curr = ord($file{0});
		
		if($file{0} == $letter || $file{0} == ucfirst($letter)){
			$chr_last = $index;
			break;
		}
		elseif($chr_curr > ord($letter))
		{
			$chr_last = $index;
			break;
		}
		elseif($chr_curr != ord($next{0})) 
			$chr_last = $index;	
	}
	
	return floor($chr_last/$items_per_page);

}

function get_nb_albums_per_page()
{
	global $config, $page_info;
	
  	switch($page_info->albumview)
	{
		case 1:
			$ret = 14;
			break;
		case 2:
			$ret = 14;
			break;
		case 3:
			$ret = 30;
			break;
		case 4:
			$ret = $config['listview_columns'] * $config['listview_rows'];
			break;
	}
	
	return $ret;

}

function create_playlist($filename)
{
	global $config;
	$pl = new Playlist($filename);
	
	$files= rglob($config['slideshow_folders'][intval($config['selected_slideshow']-1)]."/*.jpg");

	foreach($files as $file)
	{
		if(is_file($file))
			$ret[$file] = basename($file);
	}
	
	$pl->add_photos($ret);
}

function rglob($pattern, $flags = 0, $path = '') 
{
    if(empty($path) && ($dir = dirname($pattern)) != '.') 
    {
        if ($dir == '\\' || $dir == '/') 
        	$dir = '';
        return rglob(basename($pattern), $flags, $dir . '/');
    }
    $paths = glob($path . '*', GLOB_ONLYDIR);
    $files = glob($path . $pattern, $flags);

    if(is_array($paths))
    foreach($paths as $p) {
    	if(count($files) != false){
    		$new_files = rglob($pattern, $flags, $p . '/');
    		if($new_files)
		    	$files = array_merge($files, $new_files);
	   	}
	 }
    return $files;
}

function play_shuffled($filepath)
{
	global $config;
	
	if (filesize($filepath) > 1) {
		//Read playlist
		$handle = fopen($filepath, 'r');
		$data = fread($handle, filesize($filepath) - 1); //Do not fetch last \n
		fclose ($handle);
		unlink($filepath);
		
		//Shuffle playlist
		$arrData = split("\n", $data);
		shuffle($arrData);

		//Output shuffled playlist
		$handle = fopen($filepath, 'w');
		fwrite($handle, implode("\n", $arrData));
		fclose ($handle);
		
		echo "<html><body onloadset=\"start_diapo\"><a name=\"start_diapo\" href=\"MUTE\" pod=\"1,0,".$config['link']."tmp/slideshow.jsp\" ONFOCUSLOAD></body></html>";
		
	}

}


?>
