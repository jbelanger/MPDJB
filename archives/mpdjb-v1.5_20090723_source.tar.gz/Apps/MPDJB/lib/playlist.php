<?php


function get_playlists()
{	
	$ret = getLsInfo("lsinfo \"/\"");
	
	return $ret['playlist'];
}

function getPlaylistInfo($songid)
{
	global $fp;
	if(!$fp)
	 return;

	fputs($fp,"playlistinfo ".$songid."\n");
	while(!feof($fp)) {
		$got =  fgets($fp,1024);
		$got = preg_replace("/\n/","",$got);
		if(strncmp("OK",$got,strlen("OK"))==0) 
			break;
		if(strncmp("ACK",$got,strlen("ACK"))==0) {
			print "$got<br>";
			break;
		}
		$el = strtok($got,":");
		$ret["$el"] = strtok("\0");
		$ret["$el"] = preg_replace("/^ /","",$ret["$el"]);
	}
	if(!isset($ret)) $ret = array();

	return $ret;

}

function get_playlist_songs($songid = " ")
{
	exec("mpc playlist", $ret);	
	foreach($ret as $song)
	{
		if(ord($song) == ord(">")){
			$pl[] = "<FONT color=\"white\">".substr($song,strpos($song,") ")+2)."</FONT>";	
		}
		else
			$pl[] = (substr($song,strpos($song,") ")+2));
	}
	return (!empty($pl))? $pl : array();;
}

function playlist_infos($pl)
{
   global $lang;
	$nb_songs = count($pl);
 		
	$html = "<table><tr>";
	$html .= "<td valign=\"top\" class=\"albuminfo\">";
	$html .= "<font class=\"title\">".$lang['nowplaying']."</font><br />";
	
	if($nb_songs == 1)
		$html .= "<font class=\"title2\">1 ".$lang['song']."<br /></td>";
	elseif($nb_songs > 1)	
		$html .= "<font class=\"title2\">".$nb_songs." ".$lang['songs']."<br /></td>";
	else
		$html .= "<font class=\"title2\">".$lang['empty']."</td>";
		
	$html .= "</tr></table>";
		
	return $html;

}

function save_playlist_option()
{
	global $config, $page_info, $lang;
	
	$js = "\tfunction show_save_menu()\n";
	$js .= "\t{\n";

	$js .= "\t\tvar playlist_name = prompt('".$lang['playlist_name']."');\n";
	$js .= "window.location.replace(\"".$config['link']."index.php?".$page_info->path."&pg=".$page_info->pg."&action=save&param=\" + playlist_name);\n";	

	$js .= "\t}\n";
	
	return $js;
}

?>