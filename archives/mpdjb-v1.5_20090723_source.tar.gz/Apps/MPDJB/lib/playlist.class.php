<?php

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/* File taken from  PHPC 
/* Credit goes to author PHPlaylistCreator
/* See this thread:
/* http://www.networkedmediatank.com/showthread.php?tid=21272
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

global $appDir;

$appDir = "tmp/";

	class Playlist {
		var $fileName;

		function Playlist($fileName) {
			$this->fileName = $fileName;
		}

		function getFileName() {
			return $this->fileName;
		}

		function add($arrFiles) {
			global $appDir, $mediaMainDir, $mediaSubDir;
			$data = "";

			foreach ($arrFiles as $fileName) {
				$data .= "$fileName|0|0|file://$mediaMainDir$mediaSubDir/$fileName|\n";
			}

			$handle = fopen("$appDir$this->fileName", 'a');
			fwrite($handle, $data);
			fclose($handle);
		}
		
		function add_photos($arrFiles) {
			global $appDir, $mediaMainDir, $mediaSubDir;
			$data = "";

			foreach ($arrFiles as $key => $value) {
				$data .= "4|0|file://$key|\n";
			}

			$handle = fopen("$appDir$this->fileName", 'a');
			fwrite($handle, $data);
			fclose($handle);
		}


		function addPlaylist($fileName) {
			global $appDir, $mediaMainDir, $mediaSubDir;
			$handleReader = fopen("$mediaMainDir$mediaSubDir/$fileName", 'r');
			$cntFilesAdded = 0;
			$cntFilesNotFound = 0;
			$data = "";

			while (!feof($handleReader)) {
				$playlistItem = trim(preg_replace('/#.*$/', '', fgets($handleReader, 4096))); //Removes comments

				if (strlen($playlistItem) != 0) {
					if (!file_exists("$mediaMainDir$mediaSubDir/$playlistItem")) {
						$cntFilesNotFound++;
					} else {
						$cntFilesAdded++;
						$data .= "$playlistItem|0|0|file://$mediaMainDir$mediaSubDir/$playlistItem|\n";
					}
				}
			}

			fclose ($handleReader);

			if (strlen($data) != 0) {
				$handleWriter = fopen("$appDir$this->fileName", 'a');
				fwrite($handleWriter, $data);
				fclose($handleWriter);
			}

			return array($cntFilesAdded, $cntFilesNotFound);
		}

		function remove() {
			global $appDir;
			$handle = fopen("$appDir$this->fileName", 'w');
			fclose($handle);
		}

		function getLength() {
			global $appDir;

			if (!file_exists("$appDir$this->fileName")) {
				return 0;
			} elseif (filesize("$appDir$this->fileName") == 0) {
				return 0;
			} else {
				$handle = fopen("$appDir$this->fileName", 'r');
				$fileContent = fread($handle, filesize("$appDir$this->fileName"));
				fclose ($handle);
				return substr_count($fileContent, "\n");
			}
		}
	}
?>
